from __future__ import annotations
from datetime import datetime, timezone
import os, duckdb, pandas as pd
from .eodhd_client import fetch_intraday_chunked
from .utils import three_years_ago, ensure_utc_index, resample_ohlc

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
PARQUET_DIR = os.path.join(DATA_DIR, "parquet")
DB_PATH = os.path.join(DATA_DIR, "warehouse.duckdb")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PARQUET_DIR, exist_ok=True)

def _with_datetime_col(df: pd.DataFrame) -> pd.DataFrame:
    out = df.reset_index()
    if out.columns[0] != "datetime":
        out = out.rename(columns={out.columns[0]:"datetime"})
    return out

def ingest_prices(symbol: str = "EURUSD.FOREX", end_utc: datetime | None = None):
    end_utc = end_utc or datetime.now(timezone.utc)
    start_utc = three_years_ago(end_utc)

    intervals = ["1m", "5m", "1h"]
    dfs = {}
    for itv in intervals:
        df = fetch_intraday_chunked(symbol, start_utc, end_utc, interval=itv)
        if df.empty:
            print(f"[WARN] No data for {symbol} {itv}")
            continue
        df = ensure_utc_index(df)
        dfs[itv] = df
        pq = os.path.join(PARQUET_DIR, f"{symbol.replace('.','_')}_{itv}.parquet")
        df.to_parquet(pq)
        print(f"[OK] Saved {itv} -> {pq} ({len(df):,} rows)")

    base = dfs.get("1m", dfs.get("5m", dfs.get("1h")))
    if base is None or base.empty:
        print("[WARN] Cannot resample without base data.")
        return
    m15 = resample_ohlc(base, "15min")
    m30 = resample_ohlc(base, "30min")
    h4  = resample_ohlc(dfs.get("1h", base), "4h")

    for name, frame in {"m15": m15, "m30": m30, "h4": h4}.items():
        pq = os.path.join(PARQUET_DIR, f"{symbol.replace('.','_')}_{name}.parquet")
        frame.to_parquet(pq)
        print(f"[OK] Saved {name} -> {pq} ({len(frame):,} rows)")

    con = duckdb.connect(DB_PATH)
    con.execute("INSTALL httpfs; LOAD httpfs;")
    for itv, df in dfs.items():
        con.register(f"prices_{itv}_tmp", _with_datetime_col(df))
        con.execute(f"CREATE OR REPLACE TABLE prices_{itv} AS SELECT * FROM prices_{itv}_tmp")
    con.register("prices_m15_tmp", _with_datetime_col(m15))
    con.register("prices_m30_tmp", _with_datetime_col(m30))
    con.register("prices_h4_tmp",  _with_datetime_col(h4))
    con.execute("CREATE OR REPLACE TABLE prices_m15 AS SELECT * FROM prices_m15_tmp")
    con.execute("CREATE OR REPLACE TABLE prices_m30 AS SELECT * FROM prices_m30_tmp")
    con.execute("CREATE OR REPLACE TABLE prices_h4  AS SELECT * FROM prices_h4_tmp")
    con.close()
    print(f"[OK] Loaded DuckDB -> {DB_PATH}")

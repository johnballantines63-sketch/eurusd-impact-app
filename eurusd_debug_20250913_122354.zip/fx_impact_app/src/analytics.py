from __future__ import annotations

import os
import duckdb
import numpy as np
import pandas as pd

from .utils import ema

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
DB_PATH = os.path.join(DATA_DIR, "warehouse.duckdb")


# ==============================
# Impulsion & inversion stricte
# ==============================
def _compute_event_impulse(prices: pd.DataFrame, t0: pd.Timestamp) -> pd.DataFrame:
    """
    À partir d'un instant t0 (UTC), calcule:
      - MFE (max favorable excursion) en pips,
      - temps d'inversion 'strict' = max( retrace 50% , croisement EMA(9/21) )
    Retourne un DataFrame (index temps) avec colonnes 'mfe_pips', 'ema9', 'ema21' et
    attrs: 'inversion_time', 'p0', 'direction'.
    """
    prices = prices.sort_index()

    # position UTC-aware
    t0 = pd.to_datetime(t0, utc=True)
    idx = prices.index.searchsorted(t0, side="left")
    df = prices.iloc[idx:].copy()
    if df.empty:
        return df

    p0 = float(df["open"].iloc[0] if "open" in df.columns else df["close"].iloc[0])

    # EMA pour critère d'inversion
    df["ema9"] = ema(df["close"], 9)
    df["ema21"] = ema(df["close"], 21)

    # Direction initiale: selon la 1re bougie (close vs open)
    first_close = float(df["close"].iloc[0])
    d = 1 if first_close >= p0 else -1

    if d == 1:
        running_extreme = df["high"].cummax()
        df["mfe_pips"] = (running_extreme - p0) / 0.0001
        retrace_level = p0 + 0.5 * (running_extreme - p0)  # série
        cond_retrace = df["close"] <= retrace_level
        cond_flip = df["ema9"] < df["ema21"]
    else:
        running_extreme = df["low"].cummin()
        df["mfe_pips"] = (p0 - running_extreme) / 0.0001
        retrace_level = p0 - 0.5 * (p0 - running_extreme)
        cond_retrace = df["close"] >= retrace_level
        cond_flip = df["ema9"] > df["ema21"]

    first_retrace_time = df.index[cond_retrace].min() if cond_retrace.any() else pd.NaT
    first_flip_time = df.index[cond_flip].min() if cond_flip.any() else pd.NaT

    if pd.isna(first_retrace_time) or pd.isna(first_flip_time):
        inversion_time = pd.NaT
    else:
        inversion_time = max(first_retrace_time, first_flip_time)

    df.attrs["inversion_time"] = inversion_time
    df.attrs["p0"] = p0
    df.attrs["direction"] = int(d)
    return df


# ==============================
# Scoring (moves + scores)
# ==============================
def compute_scores(con: duckdb.DuckDBPyConnection, tf_table: str = "prices_5m") -> None:
    """
    Construit tables:
      - moves: MFE par horizon pour chaque événement (15m/30m/1h/4h/24h) + temps d'inversion
      - scores: agrégats par event_key (médiane impact 1h & persistance) + scores 0-100
    """
    prices = con.execute(f"SELECT * FROM {tf_table}").df()
    if prices.empty:
        print(f"[WARN] No prices in {tf_table}.")
        return
    prices["datetime"] = pd.to_datetime(prices["datetime"], utc=True)
    prices = prices.set_index("datetime").sort_index()

    events = con.execute("SELECT * FROM events").df()
    if events.empty:
        print("[WARN] No events to score.")
        return
    events["ts_utc"] = pd.to_datetime(events["ts_utc"], utc=True)

    rows = []
    for _, ev in events.iterrows():
        t0 = ev["ts_utc"]
        df = _compute_event_impulse(prices, t0)
        if df.empty:
            continue

        horizons = {
            "15m": t0 + pd.Timedelta(minutes=15),
            "30m": t0 + pd.Timedelta(minutes=30),
            "1h":  t0 + pd.Timedelta(hours=1),
            "4h":  t0 + pd.Timedelta(hours=4),
            "24h": t0 + pd.Timedelta(hours=24),
        }

        result = {
            "event_time": t0,
            "event_key": ev.get("event_key", ""),
            "country": ev.get("country", "NA"),
        }
        for k, t_h in horizons.items():
            sub = df[df.index <= t_h]
            result[f"mfe_{k}_pips"] = float(sub["mfe_pips"].max()) if not sub.empty else float("nan")

        inv_t = df.attrs.get("inversion_time", pd.NaT)
        result["time_to_retrace50"] = (inv_t - t0).total_seconds() / 60.0 if pd.notna(inv_t) else float("nan")
        rows.append(result)

    if not rows:
        print("[WARN] No event rows computed.")
        return

    moves = pd.DataFrame(rows)

    def pct_rank(s: pd.Series) -> pd.Series:
        return 100.0 * (s.rank(pct=True))

    scores = (
        moves.groupby("event_key")
        .agg({"mfe_1h_pips": "median", "time_to_retrace50": "median"})
        .rename(
            columns={
                "mfe_1h_pips": "impact_median_1h_pips",
                "time_to_retrace50": "persistence_median_min",
            }
        )
        .reset_index()
    )
    scores["score_impact_0_100"] = pct_rank(scores["impact_median_1h_pips"].fillna(0.0))
    scores["score_persist_0_100"] = pct_rank(scores["persistence_median_min"].fillna(0.0))

    con.register("moves_tmp", moves)
    con.register("scores_tmp", scores)
    con.execute("CREATE OR REPLACE TABLE moves AS SELECT * FROM moves_tmp")
    con.execute("CREATE OR REPLACE TABLE scores AS SELECT * FROM scores_tmp")
    print("[OK] Saved tables: moves, scores")


# ==============================
# Q1 — Jours à gros mouvement
# ==============================
def query_days_with_moves(
    con: duckdb.DuckDBPyConnection,
    tf_table: str = "prices_5m",
    min_pips: float = 30.0,
) -> pd.DataFrame:
    """
    Q1 — trouve les jours dont le MFE (depuis 00:00 UTC du jour) dépasse min_pips.
    Retourne: date, mfe_pips, time_to_inversion_min.
    """
    prices = con.execute(f"SELECT * FROM {tf_table}").df()
    if prices.empty:
        return pd.DataFrame(columns=["date", "mfe_pips", "time_to_inversion_min"])

    prices["datetime"] = pd.to_datetime(prices["datetime"], utc=True)
    prices = prices.set_index("datetime").sort_index()

    out_rows = []
    for day, df_day in prices.groupby(prices.index.date):
        df_day = df_day.copy()
        t0 = pd.Timestamp(day).tz_localize("UTC")
        impulse = _compute_event_impulse(df_day, t0)
        if impulse.empty:
            continue
        mfe = float(impulse["mfe_pips"].max())
        inv_t = impulse.attrs.get("inversion_time", pd.NaT)
        t_inv_min = float((inv_t - t0).total_seconds() / 60.0) if pd.notna(inv_t) else np.nan
        if mfe >= float(min_pips):
            out_rows.append({"date": str(day), "mfe_pips": mfe, "time_to_inversion_min": t_inv_min})

    return pd.DataFrame(out_rows).sort_values("date")


# ==============================
# Q2 — Méthode "Jours"
# ==============================
def link_events_to_moves(
    con: duckdb.DuckDBPyConnection,
    tf_table: str = "prices_5m",
    min_pips: float = 30.0,
    lookback_min: int = 60,
    lookahead_min: int = 15,
) -> pd.DataFrame:
    """
    Q2 — Méthode 'Basée sur Jours (Q1)':
      - Trouve les jours >= min_pips (Q1),
      - Cherche les events dans [début_jour - lookback ; fin_jour + lookahead],
      - Score par event: MFE_1h depuis l'heure de l'event.
    Fallback: si rien trouvé, bascule sur la méthode 'Basée sur Événements'.
    """
    # 1) Jours Q1
    days = query_days_with_moves(con, tf_table=tf_table, min_pips=min_pips)
    if days.empty:
        return events_triggering_moves(con, min_pips=float(min_pips), horizon="1h")

    # 2) Prix + events
    prices = con.execute(f"SELECT * FROM {tf_table}").df()
    prices["datetime"] = pd.to_datetime(prices["datetime"], utc=True)
    prices = prices.set_index("datetime").sort_index()

    events = con.execute("SELECT * FROM events").df()
    if events.empty:
        return pd.DataFrame(columns=["date", "event_time", "event_title", "event_key", "mfe_1h_pips"])
    events["ts_utc"] = pd.to_datetime(events["ts_utc"], utc=True)

    # 3) Lien
    rows = []
    for _, r in days.iterrows():
        d_start = pd.Timestamp(r["date"]).tz_localize("UTC")
        d_end = d_start + pd.Timedelta(days=1)
        w_start = d_start - pd.Timedelta(minutes=int(lookback_min))
        w_end = d_end + pd.Timedelta(minutes=int(lookahead_min))

        evs = events[(events["ts_utc"] >= w_start) & (events["ts_utc"] <= w_end)]
        if evs.empty:
            continue

        for _, ev in evs.iterrows():
            df_imp = _compute_event_impulse(prices, ev["ts_utc"])
            sub = df_imp[df_imp.index <= ev["ts_utc"] + pd.Timedelta(hours=1)]
            mfe_1h = float(sub["mfe_pips"].max()) if not sub.empty else np.nan
            rows.append(
                {
                    "date": str(r["date"]),
                    "event_time": ev["ts_utc"],
                    "event_title": ev.get("event_title", ""),
                    "event_key": ev.get("event_key", ""),
                    "mfe_1h_pips": mfe_1h,
                }
            )

    if not rows:
        return events_triggering_moves(con, min_pips=float(min_pips), horizon="1h")

    df = pd.DataFrame(rows).sort_values(["date", "event_time"]).reset_index(drop=True)
    return df


# ==============================
# Q2 — Méthode "Événements" (tolérance ±10min + fallback par temps seul)
# ==============================
def events_triggering_moves(
    con: duckdb.DuckDBPyConnection,
    min_pips: float = 30.0,
    horizon: str = "1h",
) -> pd.DataFrame:
    """
    Q2 — Méthode 'Basée sur Événements (recommandé)':
      - Prend la table 'moves' (scorée par compute_scores),
      - Filtre les events dont MFE_{horizon} >= min_pips,
      - Rattache titre/pays depuis 'events' avec tolérance temporelle ±10 minutes,
      - Fallback si la clef 'event_key' ne matche pas: appariement par temps seul (merge_asof).
      - Sortie ordonnée par event_time.
    """
    # -- moves
    moves = con.execute("SELECT * FROM moves").df()
    if moves.empty:
        return pd.DataFrame(
            columns=["event_time", "event_title", "event_key", "country", "mfe_pips", "time_to_retrace50"]
        )

    # colonne d'impact
    col = f"mfe_{horizon}_pips"
    if col not in moves.columns:
        for c_try in ["mfe_1h_pips", "mfe_30m_pips", "mfe_15m_pips", "mfe_4h_pips", "mfe_24h_pips"]:
            if c_try in moves.columns:
                col = c_try
                break
        else:
            return pd.DataFrame(
                columns=["event_time", "event_title", "event_key", "country", "mfe_pips", "time_to_retrace50"]
            )

    moves["event_time"] = pd.to_datetime(moves["event_time"], utc=True, errors="coerce")
    moves_ok = moves[moves[col] >= float(min_pips)].copy()
    if moves_ok.empty:
        return pd.DataFrame(
            columns=["event_time", "event_title", "event_key", "country", "mfe_pips", "time_to_retrace50"]
        )

    # -- events
    events = con.execute("SELECT * FROM events").df()
    if events.empty:
        out = moves_ok[["event_time", "event_key", col, "time_to_retrace50"]].copy()
        out["event_title"] = ""
        out["country"] = "NA"
        out = out.rename(columns={col: "mfe_pips"})
        return out[
            ["event_time", "event_title", "event_key", "country", "mfe_pips", "time_to_retrace50"]
        ].sort_values("event_time").reset_index(drop=True)

    # normalise noms de colonnes (insensible à la casse)
    ev = events.copy()
    ev.columns = [str(c).strip() for c in ev.columns]
    lower_map = {c.lower(): c for c in ev.columns}

    def pick(colnames: list[str]) -> str | None:
        for c in colnames:
            if c in lower_map:
                return lower_map[c]
        return None

    c_ts = pick(["ts_utc", "date", "datetime", "time", "timestamp", "event_date", "published", "released", "ts"])
    c_key = pick(["event_key"])
    c_tit = pick(
        [
            "event_title",
            "event",
            "title",
            "event_name",
            "indicator",
            "indicator_name",
            "release",
            "release_name",
            "headline",
            "name",
            "subject",
            "report",
            "description",
            "type",
            "category",
        ]
    )
    c_ctry = pick(["country", "Country"])

    if c_ts is None:
        out = moves_ok[["event_time", "event_key", col, "time_to_retrace50"]].copy()
        out["event_title"] = ""
        out["country"] = "NA"
        out = out.rename(columns={col: "mfe_pips"})
        return out[
            ["event_time", "event_title", "event_key", "country", "mfe_pips", "time_to_retrace50"]
        ].sort_values("event_time").reset_index(drop=True)

    ev[c_ts] = pd.to_datetime(ev[c_ts], utc=True, errors="coerce")
    if c_key is None:
        ev["event_key"] = ""
        c_key = "event_key"
    if c_tit is None:
        ev["event_title"] = ""
        c_tit = "event_title"
    if c_ctry is None:
        ev["country"] = "NA"
        c_ctry = "country"

    ev_small = ev[[c_ts, c_key, c_tit, c_ctry]].copy()
    ev_small = ev_small.rename(columns={c_ts: "ts_utc", c_key: "event_key", c_tit: "event_title", c_ctry: "country"})
    ev_small["event_title"] = ev_small["event_title"].fillna("")
    ev_small["country"] = ev_small["country"].fillna("NA")

    # -------------------------------
    # Étape A : appariement clé+temps (±10 min)
    # -------------------------------
    tmp = moves_ok.merge(ev_small, on="event_key", how="left", suffixes=("_m", "_e"))
    tmp["ts_utc"] = pd.to_datetime(tmp.get("ts_utc"), utc=True, errors="coerce")
    tmp["time_diff"] = (tmp["event_time"] - tmp["ts_utc"]).abs()
    tol = pd.Timedelta(minutes=10)
    tmpA = tmp[tmp["time_diff"] <= tol].copy()

    if not tmpA.empty:
        tmpA = tmpA.sort_values(["event_key", "event_time", "time_diff"]).drop_duplicates(
            subset=["event_key", "event_time"], keep="first"
        )

    # -------------------------------
    # Étape B : fallback temps seul (merge_asof, ±10 min) pour les non-appairés
    # -------------------------------
    # Déterminer les lignes de moves non couvertes par A
    if not tmpA.empty:
        matched = pd.MultiIndex.from_frame(tmpA[["event_key", "event_time"]])
        mask_unmatched = ~pd.MultiIndex.from_frame(moves_ok[["event_key", "event_time"]]).isin(matched)
        moves_unmatched = moves_ok[mask_unmatched].copy()
    else:
        moves_unmatched = moves_ok.copy()

    if not moves_unmatched.empty:
        left = moves_unmatched.sort_values("event_time").copy()
        right = ev_small.sort_values("ts_utc").copy()
        # merge_asof par temps (nearest) avec tolérance
        tmpB = pd.merge_asof(
            left,
            right,
            left_on="event_time",
            right_on="ts_utc",
            direction="nearest",
            tolerance=tol,
        )
        # garde tout (même si pas de match -> NaN), on complètera avec valeurs par défaut
        tmpB = tmpB.copy()
    else:
        tmpB = pd.DataFrame(columns=list(moves_ok.columns) + ["ts_utc", "event_title", "country"])

    # Combine A (clé+temps) et B (temps seul)
    frames = []
    if not tmpA.empty:
        frames.append(tmpA)
    if not tmpB.empty:
        frames.append(tmpB)
    if not frames:
        # rien trouvé du tout -> renvoyer moves filtrés avec defaults
        out = moves_ok[["event_time", "event_key", col, "time_to_retrace50"]].copy()
        out["event_title"] = ""
        out["country"] = "NA"
        out = out.rename(columns={col: "mfe_pips"})
        return out[
            ["event_time", "event_title", "event_key", "country", "mfe_pips", "time_to_retrace50"]
        ].sort_values("event_time").reset_index(drop=True)

    tmp_all = pd.concat(frames, ignore_index=True)

    # Construction de la sortie
    event_title = tmp_all["event_title"] if "event_title" in tmp_all.columns else pd.Series([""] * len(tmp_all), index=tmp_all.index)
    country = tmp_all["country"] if "country" in tmp_all.columns else pd.Series(["NA"] * len(tmp_all), index=tmp_all.index)
    country = country.fillna("NA")

    ttr = tmp_all["time_to_retrace50"] if "time_to_retrace50" in tmp_all.columns else pd.Series([np.nan] * len(tmp_all), index=tmp_all.index)

    out = pd.DataFrame(
        {
            "event_time": tmp_all["event_time"],
            "event_title": event_title.fillna(""),
            "event_key": tmp_all["event_key"],
            "country": country,
            "mfe_pips": tmp_all[col].astype(float),
            "time_to_retrace50": ttr,
        }
    ).sort_values("event_time").reset_index(drop=True)

    return out

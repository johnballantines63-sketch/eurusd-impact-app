from __future__ import annotations
from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta
import pandas as pd, numpy as np, pytz

TZ_APP = pytz.timezone("Europe/Zurich")

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

def to_unix(dt: datetime) -> int:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp())

def ensure_utc_index(df: pd.DataFrame, ts_col: str = "datetime") -> pd.DataFrame:
    if ts_col in df.columns:
        s = pd.to_datetime(df[ts_col], utc=True)
        df = df.drop(columns=[ts_col])
        df.index = s
    elif df.index.name is None or df.index.tz is None:
        df.index = pd.to_datetime(df.index, utc=True)
    return df.sort_index()

def resample_ohlc(df: pd.DataFrame, rule: str) -> pd.DataFrame:
    return df.resample(rule, label="right", closed="right").agg({
        "open":"first","high":"max","low":"min","close":"last",
        **({"volume":"sum"} if "volume" in df.columns else {})
    }).dropna(subset=["open","high","low","close"])

def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()

def three_years_ago(day: datetime | None = None) -> datetime:
    day = day or utc_now()
    return day - relativedelta(years=3)

# -*- coding: utf-8 -*-
from __future__ import annotations
import os
import duckdb
import pandas as pd
import numpy as np
from datetime import date, timedelta

from .eodhd_client import fetch_economic_events  # (start_date, end_date, country, limit, offset)

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
DB_PATH = os.path.join(DATA_DIR, "warehouse.duckdb")
os.makedirs(DATA_DIR, exist_ok=True)

# Pays pertinents EURUSD
DEFAULT_COUNTRIES = ["US","EA","EU","DE","FR","IT","ES","GB","CH","JP","AU","NZ"]

# Alias éventuels côté provider (EODHD renvoie souvent UK)
COUNTRY_ALIAS = {"GB": "UK"}  # on fetch en UK si on demande GB, puis on renormalise en GB

TITLE_CANDIDATES = [
    "event","event_name","indicator","indicator_name","title",
    "release","release_name","calendar_event","calendar_title",
    "headline","headline_text","name","subject","report","description","type","category"
]
NUMERIC_CANDIDATES = ["actual","previous","estimate","forecast"]

CURRENCY_HINT = {"usd":"US","eur":"EU","chf":"CH","gbp":"GB","jpy":"JP","aud":"AU","nzd":"NZ"}

# ---------------------- helpers normalisation ----------------------

def _cols_lower(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [str(c).strip() for c in out.columns]
    first = {}
    for c in out.columns:
        lc = c.lower()
        if lc not in first:
            first[lc] = c
    out = out.rename(columns={orig: lc for lc, orig in {lc:orig for lc,orig in first.items()}.items()})
    return out

def _pick_event_title_anycase(df: pd.DataFrame) -> pd.Series:
    tmp = _cols_lower(df)
    present = [c for c in TITLE_CANDIDATES if c in tmp.columns]

    def pick_row(row):
        for c in present:
            v = row.get(c, None)
            if pd.notna(v):
                s = str(v).strip()
                if s:
                    return s
        parts = []
        for c in ("category","type","currency"):
            if c in tmp.columns:
                v = row.get(c, None)
                if pd.notna(v) and str(v).strip():
                    parts.append(str(v).strip())
        return " / ".join(parts) if parts else "unknown_event"

    return tmp.apply(pick_row, axis=1)

def _normalize_importance_anycase(df: pd.DataFrame) -> pd.Series:
    tmp = _cols_lower(df)
    if "importance" in tmp.columns:
        m = {"low":0,"medium":1,"high":2}
        return tmp["importance"].astype(str).str.lower().map(m).fillna(1)
    if "impact" in tmp.columns:
        m = {"low":0,"medium":1,"high":2}
        return tmp["impact"].astype(str).str.lower().map(m).fillna(1)
    for cand in ["importance_value","importance_num","priority","weight"]:
        if cand in tmp.columns:
            s = pd.to_numeric(tmp[cand], errors="coerce")
            return (s.clip(lower=0) / max(s.max(), 1)).fillna(1) * 2
    return pd.Series(1, index=df.index)

def _normalize_country(df: pd.DataFrame) -> pd.Series:
    tmp = _cols_lower(df)
    country = tmp.get("country", pd.Series([pd.NA]*len(df)))
    country = country.astype(str).str.strip()
    country = country.where(country.ne(""), pd.NA)

    currency = tmp.get("currency", pd.Series([pd.NA]*len(df))).astype(str).str.lower().str.strip()
    from_ccy = currency.map(CURRENCY_HINT)

    out = country.copy()
    out = out.where(out.notna(), from_ccy)
    out = out.where(out.notna(), "NA")
    # Uniformise 'UK' -> 'GB' pour rester cohérent avec l’UI
    out = out.replace({"UK": "GB"})
    return out.astype(str)

def normalize_events(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df.copy()
    tmp = _cols_lower(df).copy()

    # ts_utc
    ts_cols = [c for c in ["ts_utc","date","datetime","time","timestamp","event_date","published","released","ts"] if c in tmp.columns]
    if ts_cols:
        tmp["ts_utc"] = pd.to_datetime(tmp[ts_cols[0]], utc=True, errors="coerce")
    else:
        raise RuntimeError("No recognizable datetime in events payload.")
    tmp = tmp.dropna(subset=["ts_utc"])

    tmp["country"] = _normalize_country(tmp)

    tmp["event_title"] = _pick_event_title_anycase(df)
    tmp["event_key"] = (
        tmp["event_title"].astype(str)
        .str.lower()
        .str.replace(r"[^a-z0-9]+", " ", regex=True)
        .str.replace(r"\s+", " ", regex=True)
        .str.strip()
    )

    tmp["importance_n"] = _normalize_importance_anycase(df)

    # Numériques : utiliser Float64 (nullable) pour accepter pd.NA
    for c in NUMERIC_CANDIDATES:
        if c in tmp.columns:
            tmp[c] = pd.to_numeric(tmp[c], errors="coerce").astype("Float64")
        else:
            tmp[c] = pd.Series(np.nan, index=tmp.index, dtype="Float64")

    # unit textuel
    tmp["unit"] = tmp.get("unit", pd.Series([""]*len(tmp), dtype="object")).astype(str)

    keep = ["ts_utc","country","event_title","event_key","importance_n","actual","previous","estimate","forecast","unit"]
    opt  = ["category","currency","type","source","impact","importance"]
    keep += [c for c in opt if c in tmp.columns]

    out = tmp[keep].sort_values("ts_utc").reset_index(drop=True)
    return out

# ---------------------- découpe temporelle & fetch sans pagination ----------------------

def _date_chunks(start: date, end: date, step_days: int) -> list[tuple[str,str]]:
    chunks = []
    cur = start
    while cur <= end:
        nxt = min(cur + timedelta(days=step_days-1), end)
        chunks.append((cur.isoformat(), nxt.isoformat()))
        cur = nxt + timedelta(days=1)
    return chunks

def _try_fetch(country: str, cs: str, ce: str, limit: int = 1000) -> pd.DataFrame:
    """Un seul fetch (offset=0). En cas d’erreur → DataFrame vide (pour forcer la sous-découpe)."""
    try:
        df = fetch_economic_events(cs, ce, country=country, limit=limit, offset=0)
        if df is None:
            return pd.DataFrame()
        if "country" not in df.columns and "Country" not in df.columns and len(df) > 0:
            df["country"] = country
        # normalise immédiatement l’alias 'UK' -> 'GB' si présent
        if "country" in df.columns:
            df["country"] = df["country"].astype(str).str.replace("^UK$", "GB", regex=True)
        return df
    except Exception as e:
        print(f"[WARN] fetch error {country} {cs}->{ce}: {e}")
        return pd.DataFrame()

def _fetch_recursive(country: str, cs: str, ce: str, limit: int = 1000, min_days: int = 1) -> list[pd.DataFrame]:
    """Récursif : si len==limit → re-split jusqu’à 1 jour, toujours offset=0."""
    s = pd.to_datetime(cs).date()
    e = pd.to_datetime(ce).date()
    delta_days = (e - s).days + 1

    df = _try_fetch(country, cs, ce, limit=limit)
    if df.empty:
        return []

    if len(df) < limit:
        return [df]

    if delta_days <= min_days:
        print(f"[SAT] {country} {cs}->{ce}: {len(df)} lignes (fenêtre minimale, possible truncation)")
        return [df]

    # Split en deux
    mid = s + timedelta(days=delta_days // 2)
    out = []
    out += _fetch_recursive(country, s.isoformat(), mid.isoformat(), limit=limit, min_days=min_days)
    out += _fetch_recursive(country, (mid + timedelta(days=1)).isoformat(), e.isoformat(), limit=limit, min_days=min_days)
    return out

def ingest_events(start_date: str, end_date: str, countries: list[str] | None = None):
    """
    Ingestion :
      - découpe 7 jours,
      - fetch offset=0,
      - re-split récursif si saturation,
      - concaténer, normaliser, remplacer `events`.
    """
    countries = countries or DEFAULT_COUNTRIES
    countries = [COUNTRY_ALIAS.get(c, c) for c in countries]  # GB→UK au fetch si besoin

    s = pd.to_datetime(start_date).date()
    e = pd.to_datetime(end_date).date()

    all_frames: list[pd.DataFrame] = []
    for c in countries:
        total = 0
        for (cs, ce) in _date_chunks(s, e, step_days=7):
            parts = _fetch_recursive(c, cs, ce, limit=1000, min_days=1)
            if parts:
                all_frames.extend(parts)
                total += sum(len(p) for p in parts)
        if total == 0:
            print(f"[WARN] {c}: aucune donnée collectée sur {start_date} -> {end_date}.")
        else:
            print(f"[OK] {c}: {total} lignes")

    # retire les DF vides avant concat (évite le FutureWarning de pandas)
    non_empty = [f for f in all_frames if f is not None and not f.empty]
    if not non_empty:
        print("[WARN] No events fetched across all countries.")
        return

    raw = pd.concat(non_empty, ignore_index=True)
    events = normalize_events(raw)

    with duckdb.connect(DB_PATH) as con:
        con.register("events_tmp", events)
        con.execute("CREATE OR REPLACE TABLE events AS SELECT * FROM events_tmp")
        rows_by_country = con.execute("SELECT country, COUNT(*) n FROM events GROUP BY 1 ORDER BY n DESC").df()
        span = con.execute("SELECT MIN(ts_utc) AS min_ts, MAX(ts_utc) AS max_ts FROM events").df()

    print(f"[OK] Loaded {len(events):,} events into DuckDB: {DB_PATH}")
    print("[OK] Rows by country:\n", rows_by_country.to_string(index=False))
    print("[OK] Time span:\n", span.to_string(index=False))

# -*- coding: utf-8 -*-
# fx_impact_app/src/planner.py
from __future__ import annotations
from typing import Iterable, Optional
import pandas as pd
import duckdb

TZ_LOCAL = "Europe/Zurich"

def _date_bounds_to_utc(start_date, end_date, only_future: bool = True):
    """Convertit des dates locales (Europe/Zurich) en bornes UTC [début inclus, fin exclus]."""
    now_utc = pd.Timestamp.now(tz="UTC")
    if start_date is None:
        s_local = pd.Timestamp.now(tz=TZ_LOCAL).normalize()
    else:
        s_local = pd.Timestamp(start_date, tz=TZ_LOCAL)
    if end_date is None:
        e_local = pd.Timestamp.now(tz=TZ_LOCAL) + pd.Timedelta(days=30)
    else:
        e_local = pd.Timestamp(end_date, tz=TZ_LOCAL) + pd.Timedelta(days=1)  # exclusif

    s_utc = s_local.tz_convert("UTC")
    e_utc = e_local.tz_convert("UTC")

    if only_future and s_utc < now_utc:
        s_utc = now_utc

    return s_utc, e_utc

def future_events_with_expectations(
    con: duckdb.DuckDBPyConnection,
    min_pips: float = 20.0,
    horizon_col: str = "mfe_1h_pips",
    start_date=None,
    end_date=None,
    countries: Optional[Iterable[str]] = None,
    keyword_regex: Optional[str] = None,
    only_future: bool = True,
) -> pd.DataFrame:
    """
    Retourne les événements (futurs ou fenêtre donnée) enrichis d'une expectation d'impact
    basée sur l'historique `moves` agrégé par event_key (moyenne/mediane de {horizon_col}).

    Colonnes renvoyées :
      ts_utc, event_title, event_key, country, importance_n,
      previous, estimate, forecast, actual, unit,
      exp_mean_pips, exp_median_pips, hist_n
    (Les colonnes manquantes côté base sont renvoyées en NULL pour stabilité de schéma.)
    """
    s_utc, e_utc = _date_bounds_to_utc(start_date, end_date, only_future=only_future)

    # Valide la colonne horizon
    valid_cols = {"mfe_15m_pips","mfe_30m_pips","mfe_1h_pips","mfe_4h_pips","mfe_24h_pips"}
    if horizon_col not in valid_cols:
        horizon_col = "mfe_1h_pips"

    # Schéma dynamique de events
    ev_cols = set(con.execute("PRAGMA table_info('events')").df()["name"].astype(str).str.lower().tolist())

    def has(col: str) -> bool:
        return col.lower() in ev_cols

    # Expressions robustes (NULL si absent)
    country_expr     = "COALESCE(NULLIF(e.country,''),'NA') AS country" if has("country") else "'NA' AS country"
    importance_expr  = "e.importance_n" if has("importance_n") else "NULL AS importance_n"
    prev_expr        = "e.previous" if has("previous") else "NULL AS previous"
    est_expr         = "e.estimate" if has("estimate") else "NULL AS estimate"
    fcst_expr        = "e.forecast" if has("forecast") else "NULL AS forecast"
    actual_expr      = "e.actual"   if has("actual")   else "NULL AS actual"
    unit_expr        = "e.unit"     if has("unit")     else "NULL AS unit"

    # On passe par une CTE 'E' qui normalise les colonnes attendues
    select_e = f"""
        SELECT
            e.ts_utc,
            {"e.event_title" if has("event_title") else "CAST(NULL AS VARCHAR) AS event_title"},
            {"e.event_key"   if has("event_key")   else "CAST(NULL AS VARCHAR) AS event_key"},
            {country_expr},
            {importance_expr},
            {prev_expr}, {est_expr}, {fcst_expr}, {actual_expr}, {unit_expr}
        FROM events e
        WHERE e.ts_utc >= ? AND e.ts_utc < ?
    """

    # Applique filtres pays / regex dans la couche 'E' (on a toujours event_title & country, même NULL)
    params_e = [s_utc.to_pydatetime(), e_utc.to_pydatetime()]
    if countries:
        placeholders = ",".join(["?"] * len(countries))
        select_e += f" AND country IN ({placeholders})"
        params_e += [str(c) for c in countries]
    if keyword_regex and has("event_title"):
        select_e += " AND regexp_matches(lower(event_title), ?)"
        params_e += [keyword_regex.lower()]

    # Agrégat historique moves
    con.execute(f"""
        CREATE OR REPLACE TEMP VIEW hist AS
        SELECT
            event_key,
            AVG(CASE WHEN {horizon_col} IS NOT NULL THEN {horizon_col} END) AS exp_mean_pips,
            MEDIAN(CASE WHEN {horizon_col} IS NOT NULL THEN {horizon_col} END) AS exp_median_pips,
            COUNT(*) AS hist_n
        FROM moves
        GROUP BY 1
    """)

    # Jointure finale avec seuil
    sql = f"""
        WITH E AS (
            {select_e}
        )
        SELECT
            E.ts_utc,
            E.event_title,
            E.event_key,
            E.country,
            E.importance_n,
            E.previous, E.estimate, E.forecast, E.actual, E.unit,
            h.exp_mean_pips, h.exp_median_pips, h.hist_n
        FROM E
        LEFT JOIN hist h USING(event_key)
        WHERE COALESCE(h.exp_mean_pips, 0) >= ?
        ORDER BY E.ts_utc
    """
    params = params_e + [float(min_pips)]
    df = con.execute(sql, params).df()

    # Ajoute l'heure locale pour l'affichage Streamlit
    if not df.empty:
        ts = pd.to_datetime(df["ts_utc"], utc=True, errors="coerce")
        df.insert(1, "time_ch", ts.dt.tz_convert(TZ_LOCAL))

    return df

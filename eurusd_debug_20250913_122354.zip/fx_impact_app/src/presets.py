from __future__ import annotations

"""
Presets d'expressions régulières (compatibles DuckDB, sans lookahead/inline flags).
On matche toujours sur lower(event_title) côté SQL.

Règles:
- Pas de (?i), (?=...), (?!...), etc.
- Utiliser des séquences simples: groupes ( ... | ... ), \s, ., *
"""

# ---------------------------
# Inclusifs (par famille)
# ---------------------------

PRESET_INCLUDE = {
    # Banques centrales
    "FOMC (Fed, US)": r"(fomc|federal\s+reserve|fed\b|federal\s+funds|interest\s+rate\s+decision|policy\s+rate|target\s+rate|bank\s+rate)",
    "BCE (Zone euro)": r"(ecb|bce|deposit\s+facility|main\s+refinancing|interest\s+rate\s+decision|policy\s+rate|refinancing\s+rate)",
    "BoE (UK)": r"(bank\s+of\s+england|boe\b|bank\s+rate|interest\s+rate\s+decision|policy\s+rate)",
    "SNB (Switzerland)": r"(snb|sight\s+deposit\s+rate|policy\s+rate|interest\s+rate\s+decision)",
    "BoJ (Japan)": r"(boj|bank\s+of\s+japan|policy\s+rate|interest\s+rate\s+decision)",
    "RBA (Australia)": r"(rba|reserve\s+bank\s+of\s+australia|cash\s+rate|interest\s+rate\s+decision|policy\s+rate)",
    "RBNZ (New Zealand)": r"(rbnz|reserve\s+bank\s+of\s+new\s+zealand|official\s+cash\s+rate|interest\s+rate\s+decision|policy\s+rate)",

    # Macro “phares”
    "US CPI": r"(cpi|consumer\s+price|inflation|core\s+cpi)",
    "US NFP": r"(non[-\s]?farm|payrolls?|employment\s+situation|unemployment\s+rate|average\s+hourly\s+earnings|labou?r\s+force)",
    "PMI (global)": r"(pmi|manufacturing\s+pmi|services\s+pmi|composite\s+pmi|ism)",

    # Fallbacks larges (à utiliser prudemment)
    "Décision de taux (générique)": r"(interest\s+rate\s+decision|policy\s+rate|target\s+rate|official\s+rate|refinancing\s+rate|bank\s+rate|cash\s+rate)",
}

# ---------------------------
# Exclusifs (bruit à exclure)
# ---------------------------

EXCLUDE_NOISE = r"(speech|minutes|testimony|beige\s+book)"

# ---------------------------
# Sous-preset “décision stricte”
# ---------------------------
# À utiliser en AND pour ne retenir que les véritables décisions (sans conférences/speeches)
STRICT_DECISION_REGEX = r"(interest\s+rate\s+decision|policy\s+rate|refinancing\s+rate|official\s+rate|bank\s+rate|cash\s+rate|deposit\s+facility\s+rate|federal\s+funds)"

# ---------------------------
# Confort: mapping unique
# ---------------------------

PRESET_EXCLUDE = {
    "Bruit (speeches/minutes)": EXCLUDE_NOISE
}

# Alias pratique attendu parfois
PRESET_REGEX = {
    "include": PRESET_INCLUDE,
    "exclude": PRESET_EXCLUDE,
    "strict_decision": STRICT_DECISION_REGEX,
}

# ---------------------------
# Utilitaires
# ---------------------------

CENTRAL_BANK_PRESETS = {
    "FOMC (Fed, US)",
    "BCE (Zone euro)",
    "BoE (UK)",
    "SNB (Switzerland)",
    "BoJ (Japan)",
    "RBA (Australia)",
    "RBNZ (New Zealand)",
    "Décision de taux (générique)",
}

def is_central_bank_preset(name: str) -> bool:
    return name in CENTRAL_BANK_PRESETS

def suggest_regex_for_preset(name: str) -> str:
    """Renvoie l'include-regex d'un preset connu, sinon chaîne vide."""
    return PRESET_INCLUDE.get(name, "")

# Seuils “intelligents” (pour valeur par défaut du min_pips)
SMART_THRESHOLDS = {
    "FOMC (Fed, US)": 20.0,
    "BCE (Zone euro)": 20.0,
    "BoE (UK)": 25.0,
    "SNB (Switzerland)": 20.0,
    "BoJ (Japan)": 18.0,
    "RBA (Australia)": 18.0,
    "RBNZ (New Zealand)": 20.0,
    "US CPI": 25.0,
    "US NFP": 30.0,
    "PMI (global)": 15.0,
    "Décision de taux (générique)": 20.0,
}

def smart_threshold_for(preset: str, fallback: float = 20.0) -> float:
    return SMART_THRESHOLDS.get(preset, fallback)

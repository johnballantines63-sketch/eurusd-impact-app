from __future__ import annotations
import os, time, io
from datetime import datetime, timezone
from typing import Optional, Dict, Any
import requests, pandas as pd
from .utils import to_unix

EODHD_BASE = "https://eodhd.com/api"

def get_token() -> str:
    token = os.getenv("EODHD_API_TOKEN", "").strip()
    if not token:
        raise RuntimeError("EODHD_API_TOKEN is not set. Export it or create a .env and load it before running.")
    return token

def _get(url: str, params: Dict[str, Any]) -> Any:
    for attempt in range(3):
        r = requests.get(url, params=params, timeout=30)
        if r.status_code == 200:
            try:
                return r.json()
            except Exception:
                return r.text
        if r.status_code in (429, 500, 502, 503, 504):
            time.sleep(1.5 * (attempt + 1))
            continue
        raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")
    raise RuntimeError("Failed after retries.")

def fetch_intraday(symbol: str, start: datetime, end: datetime, interval: str = "1m", fmt: str = "json") -> pd.DataFrame:
    token = get_token()
    url = f"{EODHD_BASE}/intraday/{symbol}"
    params = {"api_token": token, "interval": interval, "fmt": fmt, "from": to_unix(start), "to": to_unix(end)}
    data = _get(url, params)
    if isinstance(data, str):
        df = pd.read_csv(io.StringIO(data))
    else:
        df = pd.DataFrame(data)
    if df.empty:
        return df
    df["datetime"] = pd.to_datetime(df["datetime"], utc=True)
    return df.sort_values("datetime").set_index("datetime")

def fetch_intraday_chunked(symbol: str, start: datetime, end: datetime, interval: str) -> pd.DataFrame:
    max_days = {"1m":120, "5m":600, "1h":7200}[interval]
    cur = start
    frames = []
    while cur < end:
        nxt = min(cur + pd.DateOffset(days=max_days), end)
        df = fetch_intraday(symbol, cur, nxt, interval=interval)
        if not df.empty:
            frames.append(df)
        cur = nxt
        time.sleep(0.25)
    if not frames:
        return pd.DataFrame(columns=["open","high","low","close","volume"])
    out = pd.concat(frames).sort_index()
    return out[~out.index.duplicated(keep="last")]

def fetch_economic_events(start_date: str, end_date: str, country: Optional[str] = None,
                          type_filter: Optional[str] = None, limit: int = 1000, offset: int = 0) -> pd.DataFrame:
    token = get_token()
    url = f"{EODHD_BASE}/economic-events"
    params = {"api_token": token, "fmt": "json", "from": start_date, "to": end_date, "limit": limit, "offset": offset}
    if country:
        params["country"] = country
    if type_filter:
        params["type"] = type_filter
    data = _get(url, params)
    df = pd.DataFrame(data)
    if df.empty:
        return df
    if "date" in df.columns:
        df["ts_utc"] = pd.to_datetime(df["date"], utc=True)
    elif "datetime" in df.columns:
        df["ts_utc"] = pd.to_datetime(df["datetime"], utc=True)
    else:
        first_dt_col = next((c for c in df.columns if "date" in c or "time" in c), None)
        if first_dt_col:
            df["ts_utc"] = pd.to_datetime(df[first_dt_col], utc=True)
        else:
            raise RuntimeError("No recognizable datetime field in economic events payload.")
    return df.sort_values("ts_utc").reset_index(drop=True)

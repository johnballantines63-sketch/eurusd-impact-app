from fx_impact_app.src.fetch_prices import ingest_prices
from fx_impact_app.src.fetch_events import ingest_events
from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta

if __name__ == "__main__":
    end = datetime.now(timezone.utc)
    start = (end - relativedelta(years=3)).date().isoformat()
    ingest_prices(symbol="EURUSD.FOREX", end_utc=end)
    ingest_events(start_date=start, end_date=end.date().isoformat())

from __future__ import annotations
import os, sys
import duckdb

PROJ = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DB1  = os.path.join(PROJ, "fx_impact_app", "data", "warehouse.duckdb")
DB2  = os.path.join(PROJ, "data", "warehouse.duckdb")

def pick_db():
    for p in (DB1, DB2):
        if os.path.isfile(p) and os.path.getsize(p) > 0:
            return p
    return DB1

REQ_MOVES_COLS = [
    "event_key", "event_time",
    "mfe_15m_pips","mfe_30m_pips","mfe_1h_pips","mfe_4h_pips","mfe_24h_pips"
]

def main():
    db = pick_db()
    print(f"[INFO] DB: {db} ({os.path.getsize(db) if os.path.exists(db) else 0} bytes)")
    if not os.path.exists(db):
        print("[ERR] DuckDB introuvable. Lance d’abord l’ingestion.")
        sys.exit(1)

    con = duckdb.connect(db)
    print("[INFO] Tables:")
    try:
        print(con.execute("SHOW TABLES").df().to_string(index=False))
    except Exception as e:
        print("[ERR] SHOW TABLES:", e)

    try:
        desc = con.execute("DESCRIBE events").df()
        cols = desc["column_name"].str.lower().tolist()
        print("[OK] events présent. Colonnes:", cols)
        span = con.execute("SELECT MIN(ts_utc) AS min_ts, MAX(ts_utc) AS max_ts FROM events").df()
        per_country = con.execute("SELECT country, COUNT(*) n FROM events GROUP BY 1 ORDER BY n DESC").df()
        print("[INFO] events span:\n", span.to_string(index=False))
        print("[INFO] events par pays (top 15):\n", per_country.head(15).to_string(index=False))
    except Exception as e:
        print("[ERR] Table events inaccessible:", e)

    try:
        d2 = con.execute("DESCRIBE moves").df()
        c2 = d2["column_name"].str.lower().tolist()
        print("[OK] moves présent. Colonnes:", c2)
        miss2 = [c for c in REQ_MOVES_COLS if c not in c2]
        if miss2:
            print("[WARN] Colonnes manquantes dans moves:", miss2)
        mv_span = con.execute("SELECT MIN(event_time) AS min_t, MAX(event_time) AS max_t FROM moves").df()
        print("[INFO] moves span:\n", mv_span.to_string(index=False))
    except Exception as e:
        print("[ERR] Table moves inaccessible:", e)

    try:
        df = con.execute("""
            WITH ev AS (
              SELECT ts_utc, event_key FROM events
              WHERE ts_utc BETWEEN now() - INTERVAL 3 YEAR AND now()
            ),
            mv AS (
              SELECT event_time, event_key FROM moves
            )
            SELECT COUNT(*) AS n_links
            FROM ev JOIN mv USING(event_key)
            WHERE mv.event_time BETWEEN ev.ts_utc - INTERVAL 60 MINUTE AND ev.ts_utc + INTERVAL 60 MINUTE
        """).df()
        print("[INFO] Liens events↔moves (±60 min):", int(df.loc[0, "n_links"]))
    except Exception as e:
        print("[ERR] Test de jointure a échoué:", e)

    try:
        num_ok = con.execute("""
          SELECT
            SUM(CASE WHEN typeof(actual)   IN ('DOUBLE','INTEGER','BIGINT','DECIMAL') THEN 1 ELSE 0 END) AS ok_actual,
            SUM(CASE WHEN typeof(previous) IN ('DOUBLE','INTEGER','BIGINT','DECIMAL') THEN 1 ELSE 0 END) AS ok_previous,
            SUM(CASE WHEN typeof(estimate) IN ('DOUBLE','INTEGER','BIGINT','DECIMAL') THEN 1 ELSE 0 END) AS ok_estimate,
            SUM(CASE WHEN typeof(forecast) IN ('DOUBLE','INTEGER','BIGINT','DECIMAL') THEN 1 ELSE 0 END) AS ok_forecast
          FROM events
        """).df()
        print("[INFO] Numériques coercibles (counts):\n", num_ok.to_string(index=False))
    except Exception as e:
        print("[WARN] Vérif numériques:", e)

    con.close()
    print("[DONE] doctor.py")

if __name__ == "__main__":
    main()

# fx_impact_app/scripts/ingest_runner.py
# Simple CLI pour ingérer le calendrier EODHD sur une plage donnée et vérifier le contenu.
from __future__ import annotations

import argparse
import os
from datetime import date, timedelta

import duckdb

# On réutilise l’ingestion et le chemin DB existants
from fx_impact_app.src.fetch_events import ingest_events, DB_PATH


def _iso_or_default(start: str | None, end: str | None, past_years: int, future_days: int) -> tuple[str, str]:
    today = date.today()
    s = start or (today - timedelta(days=past_years * 365)).isoformat()
    e = end or (today + timedelta(days=future_days)).isoformat()
    return s, e


def _report():
    print(f"[INFO] DuckDB path: {DB_PATH}")
    try:
        con = duckdb.connect(DB_PATH)
        print("[INFO] Tables:", con.execute("SHOW TABLES").df())
        n_events = con.execute("SELECT count(*) AS n FROM events").df()
        print("[INFO] events rows:", int(n_events.loc[0, "n"]) if not n_events.empty else 0)

        print("[INFO] Rows by country (top 20):")
        print(con.execute("SELECT country, count(*) n FROM events GROUP BY 1 ORDER BY n DESC LIMIT 20").df())

        print("[INFO] Time span in events:")
        print(con.execute("SELECT min(ts_utc) AS min_ts, max(ts_utc) AS max_ts FROM events").df())
        con.close()
    except Exception as e:
        print("[WARN] Report failed:", e)


def main():
    parser = argparse.ArgumentParser(
        description="Ingestion calendrier EODHD -> DuckDB (events) + rapport rapide."
    )
    parser.add_argument(
        "--countries",
        nargs="+",
        required=False,
        default=["US", "EA", "EU", "DE", "FR", "IT", "ES", "GB", "CH", "JP", "AU", "NZ"],
        help="Liste de pays (codes EODHD). Conseil: passe TOUS les pays désirés en une fois (l’ingestion remplace la table).",
    )
    parser.add_argument("--past-years", type=int, default=3, help="Historique en années si --start absent.")
    parser.add_argument("--future-days", type=int, default=0, help="Jours futurs si --end absent (ex: 400).")
    parser.add_argument("--start", type=str, help="Date ISO YYYY-MM-DD (début). Prioritaire sur --past-years.")
    parser.add_argument("--end", type=str, help="Date ISO YYYY-MM-DD (fin). Prioritaire sur --future-days.")
    parser.add_argument("--report-only", action="store_true", help="N’ingère pas, affiche juste un rapport.")
    args = parser.parse_args()

    if args.report_only:
        _report()
        return

    token = os.getenv("EODHD_API_TOKEN")
    if not token:
        print("[ERROR] EODHD_API_TOKEN n’est pas défini dans l’environnement.")
        print("        export EODHD_API_TOKEN='votre_token'")
        raise SystemExit(1)

    start, end = _iso_or_default(args.start, args.end, args.past_years, args.future_days)
    print(f"[INFO] Ingestion EODHD de {start} à {end} pour pays: {', '.join(args.countries)}")
    print("[INFO] ATTENTION: la table 'events' est remplacée par le résultat de cette ingestion.")
    ingest_events(start, end, countries=args.countries)
    print("[OK] Ingestion terminée.")
    _report()


if __name__ == "__main__":
    main()

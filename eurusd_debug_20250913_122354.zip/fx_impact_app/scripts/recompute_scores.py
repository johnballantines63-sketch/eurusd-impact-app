#!/usr/bin/env python3
from __future__ import annotations
import os, argparse, duckdb
from fx_impact_app.src.analytics import compute_scores, DB_PATH

def main():
    parser = argparse.ArgumentParser(description="Recompute scores (moves/scores) from a given price table.")
    parser.add_argument("--tf", default=os.environ.get("TF_TABLE","prices_5m"),
                        help="Price table to use (prices_1m, prices_5m, prices_m15, ...). Default: prices_5m")
    args = parser.parse_args()
    tf = args.tf

    print(f"[INFO] Using DuckDB -> {DB_PATH}")
    print(f"[INFO] Recomputing scores from {tf}")
    con = duckdb.connect(DB_PATH)
    compute_scores(con, tf_table=tf)
    con.close()
    print("[OK] Recomputed scores.")

if __name__ == "__main__":
    main()

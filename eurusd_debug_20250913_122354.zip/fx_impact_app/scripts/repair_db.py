from __future__ import annotations
import os, duckdb

PROJ = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DB   = os.path.join(PROJ, "fx_impact_app", "data", "warehouse.duckdb")

ADD_COLS = [
    ("actual",   "DOUBLE"),
    ("previous", "DOUBLE"),
    ("estimate", "DOUBLE"),
    ("forecast", "DOUBLE"),
    ("unit",     "VARCHAR"),
]

def main():
    print("[INFO] DB ->", DB)
    if not os.path.isfile(DB):
        print("[ERR] DB introuvable. Lance d’abord l’ingestion.")
        return
    con = duckdb.connect(DB)
    have = set()
    try:
        desc = con.execute("DESCRIBE events").df()
        have = set(desc["column_name"].str.lower().tolist())
    except Exception as e:
        print("[ERR] Table events absente:", e)
        con.close(); return

    for col, dtype in ADD_COLS:
        if col not in have:
            print(f"[FIX] Ajoute colonne {col} {dtype}")
            con.execute(f"ALTER TABLE events ADD COLUMN {col} {dtype}")
        else:
            print(f"[OK] Colonne déjà présente: {col}")

    con.close()
    print("[DONE] repair_db.py")

if __name__ == "__main__":
    main()

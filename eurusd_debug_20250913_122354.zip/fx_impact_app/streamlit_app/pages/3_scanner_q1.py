import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

import streamlit as st, duckdb, pandas as pd, os
from fx_impact_app.src.analytics import query_days_with_moves

DB_PATH = os.path.join("fx_impact_app", "data", "warehouse.duckdb")

st.title("📈 Scanner (Q1) — Days with ≥ N pips")

TF_OPTIONS = ["prices_1m","prices_5m","prices_1h","prices_m15","prices_m30","prices_h4"]
tf = st.selectbox("Timeframe", TF_OPTIONS, index=1)
min_pips = st.number_input("Seuil (pips) ≥", min_value=1.0, value=30.0, step=1.0)

if st.button("Scan"):
    con = duckdb.connect(DB_PATH)
    df = query_days_with_moves(con, tf_table=tf, min_pips=min_pips)
    con.close()
    st.session_state["q1_results"] = df

df = st.session_state.get("q1_results", pd.DataFrame())
st.dataframe(df, width="stretch")
st.download_button("Télécharger (CSV)", data=df.to_csv(index=False), file_name="q1_days.csv", mime="text/csv")

# fx_impact_app/streamlit_app/pages/5_planner.py
# -*- coding: utf-8 -*-
from __future__ import annotations
import os
import duckdb
import pandas as pd
import streamlit as st

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "data", "warehouse.duckdb")
TZ_APP = "Europe/Zurich"

st.set_page_config(page_title="🗓️ Planner", page_icon="🗓️", layout="wide")
st.title("🗓️ Planner — événements à venir (impact attendu)")

# ------------------------- helpers -------------------------

@st.cache_data(show_spinner=False, ttl=60)
def _read_future_window(db_path: str):
    with duckdb.connect(db_path) as con:
        span = con.execute("""
            SELECT
              MIN(ts_utc) FILTER (WHERE ts_utc >= now()) AS min_future,
              MAX(ts_utc) AS max_all
            FROM events
        """).df()
        countries = con.execute("""
            SELECT country, COUNT(*) AS n
            FROM events
            WHERE ts_utc >= now()
            GROUP BY 1
            ORDER BY country
        """).df()
    return span, countries

@st.cache_data(show_spinner=False, ttl=60)
def _country_options(db_path: str):
    with duckdb.connect(db_path) as con:
        df = con.execute("""
            SELECT DISTINCT country
            FROM events
            WHERE ts_utc >= now()
            ORDER BY country
        """).df()
    return df["country"].tolist()

def _horizon_to_col(h: str) -> str:
    return {
        "15m": "mfe_15m_pips",
        "30m": "mfe_30m_pips",
        "1h":  "mfe_1h_pips",
        "4h":  "mfe_4h_pips",
        "24h": "mfe_24h_pips",
    }[h]

# Préréglages (regex resserrées) + pays implicites
PRESETS = {
    "Aucun préréglage": {
        "regex": "",
        "countries": None,
    },
    "Décision de taux (banques centrales)": {
        # liste non générique mais multi-banques
        "regex": r"(?i)\b(fomc|federal\s+reserve|\bfed\b|ecb|bce|bank\s+of\s+england|\bboe\b|snb|bank\s+of\s+japan|\bboj\b|reserve\s+bank\s+of\s+australia|\brba\b|reserve\s+bank\s+of\s+new\s+zealand|\brbnz\b|deposit\s+facility|main\s+refinancing|bank\s+rate|policy\s+rate|ycc|yield\s+curve)\b",
        "countries": None,  # on laisse l'utilisateur choisir
    },
    "FOMC (Fed, US)": {
        "regex": r"(?i)\b(fomc|federal\s+reserve|\bfed\b|dot\s*plot|summary\s+of\s+economic\s+projections|\bsep\b)\b",
        "countries": ["US"],
    },
    "BCE (Zone euro)": {
        "regex": r"(?i)\b(ecb|bce|deposit\s+facility|main\s+refinancing|\bmrefi\b|\bmro\b|monetary\s+policy\s+decision)\b",
        "countries": ["EA","EU"],
    },
    "BoE (UK)": {
        # évite 'policy' / 'rate decision' génériques
        "regex": r"(?i)\b(bank\s+of\s+england|\bboe\b|\bbank\s+rate\b|monetary\s+policy\s+committee|\bmpc\b)\b",
        "countries": ["GB"],
    },
    "SNB (CH)": {
        "regex": r"(?i)\b(snb|swiss\s+national\s+bank|policy\s+rate|snb\s+policy)\b",
        "countries": ["CH"],
    },
    "BoJ (JP)": {
        "regex": r"(?i)\b(bank\s+of\s+japan|\bboj\b|ycc|yield\s+curve\s+control|policy\s+rate)\b",
        "countries": ["JP"],
    },
    "RBA (AU)": {
        "regex": r"(?i)\b(reserve\s+bank\s+of\s+australia|\brba\b|cash\s+rate|policy\s+rate)\b",
        "countries": ["AU"],
    },
    "RBNZ (NZ)": {
        "regex": r"(?i)\b(reserve\s+bank\s+of\s+new\s+zealand|\brbnz\b|official\s+cash\s+rate|ocr|policy\s+rate)\b",
        "countries": ["NZ"],
    },
}

@st.cache_data(show_spinner=True, ttl=60)
def _query_planner(db_path: str,
                   start_utc: pd.Timestamp,
                   end_utc: pd.Timestamp,
                   countries: list[str],
                   horizon_col: str,
                   min_pips: float,
                   min_samples: int,
                   regex_filter: str | None) -> pd.DataFrame:
    """
    Joint les events futurs [start,end] aux stats historiques des moves (par event_key, country),
    filtre sur impact attendu (médiane MFE) et applique un filtre regex optionnel sur le titre.
    """
    if not countries:
        return pd.DataFrame()

    placeholders = ",".join(["?"] * len(countries))  # IN (?, ?, ?)
    hist_sql = f"""
        WITH hist AS (
          SELECT
            event_key,
            country,
            median({horizon_col}) AS exp_pips,
            count(*)               AS samples
          FROM moves
          WHERE {horizon_col} IS NOT NULL
          GROUP BY 1,2
        )
        SELECT
          e.ts_utc,
          e.country,
          e.event_title,
          e.event_key,
          h.exp_pips,
          h.samples
        FROM events e
        LEFT JOIN hist h
          ON h.event_key = e.event_key AND h.country = e.country
        WHERE e.ts_utc >= ? AND e.ts_utc <= ?
          AND e.country IN ({placeholders})
    """
    bind = [start_utc, end_utc, *countries]

    if regex_filter and regex_filter.strip():
        hist_sql += " AND regexp_matches(lower(e.event_title), ?)"
        bind.append(regex_filter)

    with duckdb.connect(db_path) as con:
        con.execute("PRAGMA threads=4")
        df = con.execute(hist_sql, bind).df()

    if df.empty:
        return df

    df["ts_local"] = pd.to_datetime(df["ts_utc"], utc=True).dt.tz_convert(TZ_APP)
    df["impact_attendu_pips"] = df["exp_pips"].fillna(0.0)
    df = df[df["impact_attendu_pips"].abs() >= float(min_pips)].copy()
    df = df[df["samples"].fillna(0) >= int(min_samples)].copy()
    df = df.sort_values(["ts_utc", "country", "impact_attendu_pips"], ascending=[True, True, False])
    return df

# ------------------------- UI -------------------------

span, countries_df = _read_future_window(DB_PATH)
min_future_utc = span.loc[0, "min_future"]
max_all_utc    = span.loc[0, "max_all"]

if pd.isna(max_all_utc):
    st.warning("Aucun événement en base. Lance d’abord l’ingestion des événements.")
    st.stop()

today_local = pd.Timestamp.now(tz=TZ_APP).normalize()
min_future_local = (pd.to_datetime(min_future_utc, utc=True).tz_convert(TZ_APP).normalize()
                    if pd.notna(min_future_utc) else today_local)
max_all_local = pd.to_datetime(max_all_utc, utc=True).tz_convert(TZ_APP)

with st.sidebar:
    st.subheader("Filtres")

    start_date = st.date_input(
        "Date début",
        value=max(today_local.date(), min_future_local.date()),
        min_value=min_future_local.date(),
        max_value=max_all_local.date(),
    )
    end_date = st.date_input(
        "Date fin",
        value=max_all_local.date(),
        min_value=start_date,
        max_value=max_all_local.date(),
    )

    # Pays (futurs disponibles)
    opts = _country_options(DB_PATH)
    sel_countries = st.multiselect("Pays", options=opts, default=opts)

    # Préréglages + filtre libre
    preset_name = st.selectbox("Préréglage d’événements", list(PRESETS.keys()), index=0)
    preset_cfg = PRESETS.get(preset_name, {"regex": "", "countries": None})
    keyword = st.text_input("Filtrer par mot-clé / regex (optionnel)", value="")
    limit_to_preset_countries = st.checkbox(
        "Limiter aux pays du préréglage (conseillé)",
        value=(preset_name != "Aucun préréglage")
    )

    # Horizon + seuils
    horizon = st.selectbox("Horizon", ["15m", "30m", "1h", "4h", "24h"], index=2)
    min_pips = st.number_input("Seuil impact attendu (pips)", min_value=0.0, value=20.0, step=5.0)
    min_samples = st.number_input("Échantillons historiques (min)", min_value=0, value=3, step=1)

# Fenêtre locale → UTC (fermée)
start_local = pd.Timestamp(start_date).tz_localize(TZ_APP)
end_local   = pd.Timestamp(end_date).tz_localize(TZ_APP) + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
start_utc   = start_local.tz_convert("UTC")
end_utc     = end_local.tz_convert("UTC")

# Pays effectifs selon préréglage
effective_countries = sel_countries[:]
if limit_to_preset_countries and preset_cfg.get("countries"):
    target = preset_cfg["countries"]
    inter = [c for c in sel_countries if c in target]
    if inter:
        effective_countries = inter
    else:
        # si l'utilisateur n'a pas coché les pays cibles, on applique ceux dispo
        effective_countries = [c for c in target if c in opts]
        # si rien de dispo, on retombe sur la sélection utilisateur
        if not effective_countries:
            effective_countries = sel_countries[:]

# Regex finale = préréglage ⊕ mot-clé libre
regex_final = ""
preset_rx = preset_cfg.get("regex", "")
if preset_rx and keyword.strip():
    regex_final = f"({preset_rx})|({keyword})"
elif preset_rx:
    regex_final = preset_rx
else:
    regex_final = keyword.strip() if keyword.strip() else ""

# Info fenêtre DB
st.info(
    f"Fenêtre future en base : "
    f"{min_future_local.strftime('%Y-%m-%d')} → {max_all_local.strftime('%Y-%m-%d %H:%M %Z')} "
    f"• Pays futurs dispo: {', '.join(countries_df['country'].tolist())}"
)

# Requête
if not effective_countries:
    st.warning("Aucun pays effectif à interroger. Vérifie la sélection / préréglage.")
    st.stop()

hcol = _horizon_to_col(horizon)
df = _query_planner(
    DB_PATH,
    start_utc, end_utc,
    effective_countries,
    hcol,
    min_pips=min_pips,
    min_samples=min_samples,
    regex_filter=regex_final if regex_final else None,
)

# Résumé & pays manquants
if df is None or df.empty:
    present = set(countries_df["country"].tolist())
    missing = [c for c in effective_countries if c not in present]
    st.error("Aucun événement ne satisfait les critères.")
    if missing:
        st.caption("Pays sélectionnés sans événements futurs dans la base : " + ", ".join(missing))
    st.stop()

applied_info = f"Pays appliqués : {', '.join(effective_countries)}"
if preset_cfg.get("countries") and limit_to_preset_countries:
    applied_info += f" (préréglage {preset_name})"

st.write(
    f"**Résultats :** {len(df):,} lignes • {applied_info} • "
    f"Horizon **{horizon}** • Seuil **{min_pips:.0f} pips** • **≥ {int(min_samples)}** échantillons"
)

# Affichage
disp = df[["ts_local","country","event_title","impact_attendu_pips","samples"]].rename(columns={
    "ts_local": "Date/Heure (local)",
    "country": "Pays",
    "event_title": "Événement",
    "impact_attendu_pips": "Impact attendu (pips)",
    "samples": "Nb. échantillons",
})
st.dataframe(disp, width='stretch', hide_index=True)

st.caption(
    "Astuce : coche “Limiter aux pays du préréglage” pour éviter que le filtre regex n’attrape des annonces d’autres banques centrales "
    "(ex. BoE → UK uniquement). Les regex des préréglages ont été resserrées pour réduire les faux positifs."
)

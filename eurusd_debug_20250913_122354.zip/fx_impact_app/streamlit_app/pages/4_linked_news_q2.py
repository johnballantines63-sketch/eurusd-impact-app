# fx_impact_app/streamlit_app/pages/4_linked_news_q2.py
# -*- coding: utf-8 -*-
from __future__ import annotations
import os
import duckdb
import pandas as pd
import streamlit as st

from fx_impact_app.src.presets import (
    PRESET_INCLUDE, PRESET_EXCLUDE, STRICT_DECISION_REGEX, EXCLUDE_NOISE_REGEX, is_central_bank_preset
)

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "data", "warehouse.duckdb")
TZ_APP = "Europe/Zurich"

st.set_page_config(page_title="🔗 Q2 — Liens événements ↔ mouvements", page_icon="🔗", layout="wide")
st.title("🔗 Q2 — Relier les plus gros mouvements aux annonces (avec chiffres & surprise)")

def _hcol(h: str) -> str:
    return {
        "15m": "mfe_15m_pips",
        "30m": "mfe_30m_pips",
        "1h":  "mfe_1h_pips",
        "4h":  "mfe_4h_pips",
        "24h": "mfe_24h_pips",
    }[h]

@st.cache_data(show_spinner=False, ttl=60)
def _country_options(db_path: str):
    with duckdb.connect(db_path) as con:
        return con.execute("SELECT DISTINCT country FROM events ORDER BY country").df()["country"].tolist()

@st.cache_data(show_spinner=True, ttl=60)
def _link_with_numbers(db_path: str,
                       start_utc: pd.Timestamp,
                       end_utc: pd.Timestamp,
                       countries: list[str],
                       horizon_col: str,
                       min_pips: float,
                       tol_minutes: int,
                       include_regex: str | None,
                       preset_exclude_regex: str | None,
                       strict_decisions: bool,
                       exclude_noise: bool) -> pd.DataFrame:
    if not countries:
        return pd.DataFrame()

    placeholders = ",".join(["?"] * len(countries))
    where = [
        "ts_utc BETWEEN ? AND ?",
        f"country IN ({placeholders})"
    ]
    bind = [start_utc, end_utc, *countries]

    if include_regex and include_regex.strip():
        where.append("regexp_matches(lower(event_title), ?)")
        bind.append(include_regex)

    if preset_exclude_regex and preset_exclude_regex.strip():
        where.append("NOT regexp_matches(lower(event_title), ?)")
        bind.append(preset_exclude_regex)

    if strict_decisions:
        where.append("regexp_matches(lower(event_title), ?)")
        bind.append(STRICT_DECISION_REGEX)

    if exclude_noise:
        where.append("NOT regexp_matches(lower(event_title), ?)")
        bind.append(EXCLUDE_NOISE_REGEX)

    sql = f"""
    WITH ev AS (
      SELECT
        ts_utc, country, event_title, event_key,
        actual, previous, estimate, forecast
      FROM events
      WHERE {" AND ".join(where)}
    ),
    mv AS (
      SELECT event_time, event_key, country, {horizon_col} AS mfe
      FROM moves
      WHERE {horizon_col} IS NOT NULL
        AND event_time BETWEEN ? AND ?
    ),
    matched AS (
      SELECT
        mv.event_time, ev.ts_utc,
        ev.country, ev.event_title, ev.event_key,
        mv.mfe, ev.actual, ev.previous, ev.estimate, ev.forecast
      FROM mv
      JOIN ev
        ON ev.event_key = mv.event_key
       AND ev.country   = mv.country
       AND ev.ts_utc BETWEEN mv.event_time - INTERVAL {tol_minutes} MINUTE
                         AND mv.event_time + INTERVAL {tol_minutes} MINUTE
    )
    SELECT
      event_time, ts_utc, country, event_title, event_key,
      mfe,
      actual,
      previous,
      COALESCE(estimate, forecast) AS consensus,
      (actual - COALESCE(estimate, forecast))                 AS surprise_pts,
      CASE
        WHEN COALESCE(estimate, forecast) IS NOT NULL
             AND COALESCE(estimate, forecast) != 0
        THEN 100.0 * (actual - COALESCE(estimate, forecast)) / ABS(COALESCE(estimate, forecast))
        ELSE NULL
      END                                                     AS surprise_pct
    FROM matched
    WHERE ABS(mfe) >= ?
    ORDER BY event_time
    """
    bind2 = bind + [start_utc, end_utc, float(min_pips)]

    with duckdb.connect(db_path) as con:
        df = con.execute(sql, bind2).df()

    if df.empty:
        return df

    df["event_local"] = pd.to_datetime(df["event_time"], utc=True).dt.tz_convert(TZ_APP)
    df["annonce_local"] = pd.to_datetime(df["ts_utc"], utc=True).dt.tz_convert(TZ_APP)
    return df

# -------- UI --------
with st.sidebar:
    st.subheader("Filtres")
    today_local = pd.Timestamp.now(tz=TZ_APP).normalize()
    start_date = st.date_input("Date début", value=(today_local - pd.DateOffset(years=3)).date())
    end_date   = st.date_input("Date fin", value=today_local.date(), min_value=start_date)

    countries = st.multiselect("Pays",
                               options=_country_options(DB_PATH),
                               default=["US","EA","EU","GB","JP","CH","AU","NZ"])

    preset_name = st.selectbox("Préréglage d’événements", list(PRESET_INCLUDE.keys()), index=0)
    keyword = st.text_input("Filtrer par mot-clé / regex (optionnel)")

    _is_cb = is_central_bank_preset(preset_name)
    strict_decisions = st.checkbox("Décisions strictes uniquement", value=_is_cb)
    exclude_noise    = st.checkbox("Exclure speeches / minutes / press / statement", value=_is_cb)

    horizon = st.selectbox("Horizon", ["15m","30m","1h","4h","24h"], index=2)
    min_pips = st.number_input("Seuil de mouvement (pips, abs)", min_value=0.0, value=30.0, step=5.0)
    tol_min  = st.number_input("Tolérance temporelle ± (minutes)", min_value=1, value=10, step=1)

    btn = st.button("Lister")

start_utc = pd.Timestamp(start_date).tz_localize(TZ_APP).tz_convert("UTC")
end_utc   = (pd.Timestamp(end_date).tz_localize(TZ_APP) + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)).tz_convert("UTC")

preset_rx = PRESET_INCLUDE.get(preset_name, "")
if preset_rx and keyword.strip():
    include_regex = f"({preset_rx})|({keyword})"
elif preset_rx:
    include_regex = preset_rx
else:
    include_regex = keyword.strip() if keyword.strip() else None

preset_exclude = PRESET_EXCLUDE.get(preset_name, "")

if btn:
    st.write(f"*Recherche… horizon **{horizon}**, seuil **{min_pips:.0f} pips**, tolérance ±**{int(tol_min)} min***")

    df = _link_with_numbers(
        DB_PATH,
        start_utc, end_utc,
        countries,
        _hcol(horizon),
        min_pips=float(min_pips),
        tol_minutes=int(tol_min),
        include_regex=include_regex,
        preset_exclude_regex=preset_exclude,
        strict_decisions=bool(strict_decisions),
        exclude_noise=bool(exclude_noise),
    )

    if df.empty:
        st.error("Aucun lien trouvé avec ces critères. Élargis la période, augmente la tolérance ou baisse le seuil.")
        st.stop()

    total = len(df)
    st.success(f"Résultats : **{total:,}** lignes")

    show = df[[
        "event_local","annonce_local","country","event_title",
        "mfe","actual","consensus","previous","surprise_pts","surprise_pct"
    ]].rename(columns={
        "event_local": "Heure move (local)",
        "annonce_local": "Heure annonce (local)",
        "country": "Pays",
        "event_title": "Événement",
        "mfe": f"MFE {horizon} (pips)",
        "actual": "Actuel",
        "consensus": "Consensus",
        "previous": "Précédent",
        "surprise_pts": "Surprise (pts)",
        "surprise_pct": "Surprise (%)",
    })

    for col in [f"MFE {horizon} (pips)", "Actuel", "Consensus", "Précédent", "Surprise (pts)", "Surprise (%)"]:
        if col in show.columns:
            show[col] = pd.to_numeric(show[col], errors="coerce")

    st.dataframe(show, hide_index=True, width='stretch')
    st.caption("Surprise (%) = (Actuel − Consensus) / |Consensus| × 100. Consensus = Estimate si présent, sinon Forecast.")
else:
    st.info("Configure puis clique **Lister** pour lancer la recherche.")

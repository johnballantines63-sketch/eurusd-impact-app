import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

import streamlit as st, duckdb, pandas as pd, os
from fx_impact_app.src.analytics import compute_scores

DB_PATH = os.path.join("fx_impact_app", "data", "warehouse.duckdb")

st.title("🔎 Discovery — Compute Impact & Persistence Scores")

TF_OPTIONS = ["prices_1m","prices_5m","prices_1h","prices_m15","prices_m30","prices_h4"]
tf = st.selectbox("Timeframe for scoring", TF_OPTIONS, index=1)

if st.button("Compute / Recompute scores"):
    con = duckdb.connect(DB_PATH)
    compute_scores(con, tf_table=tf)
    con.close()
    st.success(f"Scores recomputed using {tf}.")

con = duckdb.connect(DB_PATH)
tables = con.execute("SHOW TABLES").df()["name"].values.tolist()
scores = con.execute("SELECT * FROM scores").df() if "scores" in tables else pd.DataFrame()
con.close()

st.dataframe(scores.head(50))
st.download_button("Download scores CSV", data=scores.to_csv(index=False), file_name="scores.csv", mime="text/csv")

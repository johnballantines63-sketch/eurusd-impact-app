import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

import streamlit as st
import pandas as pd
from fx_impact_app.src.fetch_prices import ingest_prices
from fx_impact_app.src.fetch_events import ingest_events

st.title("📥 Ingestion — Prices & Events (EODHD)")
st.caption("Stockage UTC • Affichage Europe/Zurich • Token requis: EODHD_API_TOKEN")

token_present = bool(os.getenv("EODHD_API_TOKEN"))
st.sidebar.markdown("### État du token EODHD")
st.sidebar.write("Présent ✅" if token_present else "Manquant ❌")

with st.expander("Configurer le token (optionnel si déjà exporté dans le shell)"):
    tok = st.text_input("EODHD_API_TOKEN", value=os.getenv("EODHD_API_TOKEN",""), type="password")
    if st.button("Utiliser ce token", key="btn_set_token"):
        if tok.strip():
            os.environ["EODHD_API_TOKEN"] = tok.strip()
            st.success("Token chargé dans l'environnement de cette session.")
        else:
            st.warning("Token vide — rien n'a été changé.")

st.divider()

st.subheader("Intraday Prices (EURUSD.FOREX)")
with st.form("form_prices", clear_on_submit=False):
    symbol = st.text_input("Symbol", value="EURUSD.FOREX", key="symbol_input")
    end_date = st.date_input("End date (UTC) pour les PRICES", value=pd.Timestamp.utcnow().date(), key="prices_end")
    submit_prices = st.form_submit_button("Fetcher PRICES (3 ans en arrière)", width="stretch")
    if submit_prices:
        try:
            with st.spinner("Téléchargement PRICES en cours…"):
                end_dt_utc = pd.Timestamp(end_date).tz_localize("UTC").to_pydatetime()
                ingest_prices(symbol=symbol, end_utc=end_dt_utc)
            st.success("✅ PRICES ingérés (1m/5m/1h) + resamples (m15/m30/h4).")
        except Exception as e:
            st.error(f"Erreur PRICES: {e}")

st.divider()

st.subheader("Economic Events")
with st.form("form_events", clear_on_submit=False):
    col1, col2 = st.columns(2)
    with col1:
        events_start = st.date_input("Events start (YYYY-MM-DD)", value=(pd.Timestamp.utcnow() - pd.DateOffset(years=3)).date(), key="events_start")
    with col2:
        events_end = st.date_input("Events end (YYYY-MM-DD)", value=pd.Timestamp.utcnow().date(), key="events_end")
    submit_events = st.form_submit_button("Fetcher EVENTS (start → end)", width="stretch")
    if submit_events:
        try:
            with st.spinner("Téléchargement EVENTS en cours…"):
                ingest_events(start_date=str(events_start), end_date=str(events_end))
            st.success("✅ EVENTS ingérés/actualisés.")
        except Exception as e:
            st.error(f"Erreur EVENTS: {e}")

st.info("Astuce: après ingestion, va sur 🔎 Discovery pour recalculer les scores si nécessaire.")

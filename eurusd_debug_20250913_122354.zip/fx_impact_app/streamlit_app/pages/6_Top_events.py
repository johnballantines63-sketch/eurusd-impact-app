# fx_impact_app/streamlit_app/pages/6_Top_events.py

from __future__ import annotations
import os
from datetime import date, datetime, timedelta, timezone

import duckdb
import pandas as pd
import streamlit as st

# -------------------------------------------------------------------
# Fallback presets (au cas où fx_impact_app.src.presets n’existe pas)
# -------------------------------------------------------------------
DEFAULT_PRESET_INCLUDE = {
    "Banques centrales": {
        "Toutes BC (larges)": r"(fomc|federal\s+reserve|ecb|bce|bank\s+of\s+england|boe|snb|boj|rba|rbnz|policy|interest\s+rate|deposit\s+facility|refinancing|bank\s+rate)",
        "FOMC (Fed, US)": r"(fomc|federal\s+reserve|fed\b|federal\s+funds|interest\s+rate\s+decision)",
        "BCE (Zone euro)": r"(ecb|bce|deposit\s+facility|main\s+refinancing|interest\s+rate\s+decision)",
        "BoE (Royaume-Uni)": r"(bank\s+of\s+england|boe|bank\s+rate|interest\s+rate\s+decision)",
        "SNB (Suisse)": r"(snb|interest\s+rate\s+decision)",
        "BoJ (Japon)": r"(boj|bank\s+of\s+japan|policy\s+rate|interest\s+rate\s+decision)",
        "RBA (Australie)": r"(rba|reserve\s+bank\s+of\s+australia|cash\s+rate|interest\s+rate\s+decision)",
        "RBNZ (Nouvelle-Zélande)": r"(rbnz|official\s+cash\s+rate|interest\s+rate\s+decision)",
    },
    "Inflation": {
        "US — CPI/PCE (large)": r"(cpi|consumer\s+price|pce|inflation\s+rate|core\s+cpi|core\s+pce)",
        "EA/EU — HICP/CPI": r"(hicp|harmonis(e|ed)\s+inflation|cpi|inflation\s+rate)",
    },
    "Emploi (US)": {
        "US — NFP & chômage": r"(non[-\s]?farm|payroll|unemployment|employment\s+situation|average\s+hourly\s+earnings|labou?r)",
    },
    "Activité/PMI": {
        "PMI (tous)": r"(pmi|manufacturing\s+pmi|services\s+pmi|composite\s+pmi)",
    },
}

DEFAULT_EXCLUDE_NOISE = r"(speech|remarks|minutes|testimony|press\s+conference|beige\s+book|q&a)"

STRICT_DECISIONS_REGEX = r"(interest\s+rate\s+decision|deposit\s+facility|main\s+refinancing|federal\s+funds\s+(target\s+range|rate)|bank\s+rate|policy\s+rate)"

try:
    from fx_impact_app.src.presets import (
        PRESET_INCLUDE as PRESET_INCLUDE_EXT,
        EXCLUDE_NOISE_REGEX as EXCLUDE_NOISE_EXT,
        STRICT_DECISION_REGEX as STRICT_DECISION_EXT,
    )
    PRESET_INCLUDE = PRESET_INCLUDE_EXT
    EXCLUDE_NOISE_REGEX = EXCLUDE_NOISE_EXT
    STRICT_DECISION_REGEX = STRICT_DECISION_EXT
except Exception:
    PRESET_INCLUDE = DEFAULT_PRESET_INCLUDE
    EXCLUDE_NOISE_REGEX = DEFAULT_EXCLUDE_NOISE
    STRICT_DECISION_REGEX = STRICT_DECISIONS_REGEX

# -------------------------------------------------------------------
# Constantes & helpers
# -------------------------------------------------------------------
DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "data")
DB_PATH = os.path.abspath(os.path.join(DATA_DIR, "warehouse.duckdb"))

HCOLS = {
    "15m": "mfe_15m_pips",
    "30m": "mfe_30m_pips",
    "1h": "mfe_1h_pips",
    "4h": "mfe_4h_pips",
    "24h": "mfe_24h_pips",
}

def _as_timestamp_utc(d: date, end_of_day=False) -> pd.Timestamp:
    if isinstance(d, pd.Timestamp):
        t = d
    else:
        t = pd.Timestamp(d)
    if end_of_day:
        t = t + pd.Timedelta(days=1)
    if t.tzinfo is None:
        return t.tz_localize("UTC")
    return t.tz_convert("UTC")

def _countries_condition(countries: list[str]) -> tuple[str, list]:
    # Si liste vide => pas de filtre pays
    if not countries:
        return "", []
    # Bind sur placeholders
    placeholders = ",".join(["?"] * len(countries))
    return f"AND country IN ({placeholders})", list(countries)

def _regex_condition(col: str, pattern: str | None) -> tuple[str, list]:
    if pattern and pattern.strip():
        # case-insensitive via lower()
        return f"AND regexp_matches(lower({col}), ?)", [pattern.lower()]
    return "", []

def _not_regex_condition(col: str, pattern: str | None) -> tuple[str, list]:
    if pattern and pattern.strip():
        return f"AND NOT regexp_matches(lower({col}), ?)", [pattern.lower()]
    return "", []

@st.cache_data(show_spinner=False)
def _available_countries(db_path: str) -> list[str]:
    with duckdb.connect(db_path) as con:
        rows = con.execute("SELECT DISTINCT country FROM events ORDER BY 1").fetchall()
    return [r[0] for r in rows if r[0]]

@st.cache_data(show_spinner=False)
def _filter_count(
    db_path: str,
    start_utc: pd.Timestamp,
    end_utc: pd.Timestamp,
    countries: list[str],
    include_regex: str | None,
    exclude_regex: str | None,
    strict_decision: bool,
) -> int:
    c_cond, c_bind = _countries_condition(countries)
    i_cond, i_bind = _regex_condition("event_title", include_regex)
    e_cond, e_bind = _not_regex_condition("event_title", exclude_regex)
    s_cond, s_bind = _regex_condition("event_title", STRICT_DECISION_REGEX if strict_decision else None)

    sql = f"""
        SELECT COUNT(*) AS n
        FROM events
        WHERE ts_utc >= ? AND ts_utc < ?
        {c_cond} {i_cond} {e_cond} {s_cond}
    """
    bind = [start_utc, end_utc, *c_bind, *i_bind, *e_bind, *s_bind]
    with duckdb.connect(db_path) as con:
        return int(con.execute(sql, bind).fetchone()[0])

@st.cache_data(show_spinner=False)
def _top_events_with_dates(
    db_path: str,
    start_utc: pd.Timestamp,
    end_utc: pd.Timestamp,
    countries: list[str],
    hcol: str,
    min_pips_thresh: float,
    min_samples_past: int,
    include_regex: str | None,
    exclude_regex: str | None,
    strict_decision: bool,
    n_recent: int,
):
    c_cond, c_bind = _countries_condition(countries)
    i_cond, i_bind = _regex_condition("event_title", include_regex)
    e_cond, e_bind = _not_regex_condition("event_title", exclude_regex)
    s_cond, s_bind = _regex_condition("event_title", STRICT_DECISION_REGEX if strict_decision else None)

    # Agrégat par (event_key, country)
    agg_sql = f"""
    WITH ev AS (
      SELECT ts_utc, country, event_key, event_title
      FROM events
      WHERE ts_utc >= ? AND ts_utc < ?
      {c_cond} {i_cond} {e_cond} {s_cond}
    ),
    j AS (
      SELECT
        ev.event_key, ev.country, ev.event_title,
        ev.ts_utc AS event_time,
        ABS(m.{hcol}) AS mfe
      FROM ev
      LEFT JOIN moves m
        ON m.event_key = ev.event_key
       AND m.country   = ev.country
       AND m.event_time= ev.ts_utc
    ),
    stats AS (
      SELECT
        event_key,
        country,
        ANY_VALUE(event_title) AS event_title,
        COUNT(*) AS samples_total,
        SUM(CASE WHEN event_time < now() THEN 1 ELSE 0 END)  AS samples_past,
        SUM(CASE WHEN event_time >= now() THEN 1 ELSE 0 END) AS samples_future,
        MEDIAN(CASE WHEN event_time < now() THEN mfe END)     AS median_mfe_past,
        AVG(   CASE WHEN event_time < now() THEN mfe END)     AS avg_mfe_past,
        SUM(CASE WHEN event_time < now() AND mfe >= ? THEN 1 ELSE 0 END) AS hits_ge_thresh_past
      FROM j
      GROUP BY 1,2
    )
    SELECT *
    FROM stats
    WHERE samples_past >= ?
      AND (COALESCE(median_mfe_past,0) >= ? OR hits_ge_thresh_past > 0)
    ORDER BY samples_past DESC, median_mfe_past DESC
    """
    agg_bind = [start_utc, end_utc, *c_bind, *i_bind, *e_bind, *s_bind,
                float(min_pips_thresh), int(min_samples_past), float(min_pips_thresh)]

    with duckdb.connect(db_path) as con:
        agg = con.execute(agg_sql, agg_bind).df()

        # Récents/à venir pour les clés retenues
        if len(agg) == 0 or n_recent <= 0:
            recent = pd.DataFrame(columns=["ts_utc","country","event_title","event_key"])
        else:
            keys = agg["event_key"].dropna().unique().tolist()
            if not keys:
                recent = pd.DataFrame(columns=["ts_utc","country","event_title","event_key"])
            else:
                placeholders = ",".join(["?"] * len(keys))
                recent_sql = f"""
                  SELECT ts_utc, country, event_title, event_key
                  FROM events
                  WHERE ts_utc >= now()
                    {c_cond}
                    AND event_key IN ({placeholders})
                  ORDER BY ts_utc
                  LIMIT ?
                """
                recent = con.execute(recent_sql, [*c_bind, *keys, int(n_recent)]).df()

    return agg, recent

# -------------------------------------------------------------------
# UI
# -------------------------------------------------------------------
st.set_page_config(page_title="📊 Top events", page_icon="📊", layout="wide")
st.title("📊 Top events — agrégats par type/pays")

st.caption(f"DB: `{DB_PATH}`")

# Dates — défaut = 3 ans en arrière → aujourd’hui
today = date.today()
default_start = today - timedelta(days=3*365)
default_end = today

col_dates = st.columns(2)
start_d = col_dates[0].date_input("Date début", value=default_start, format="YYYY/MM/DD")
end_d   = col_dates[1].date_input("Date fin",   value=default_end,   format="YYYY/MM/DD")

start_utc = _as_timestamp_utc(start_d)
end_utc   = _as_timestamp_utc(end_d, end_of_day=True)

# Pays disponibles
all_countries = _available_countries(DB_PATH)
default_c = [c for c in ("US","EA","EU","GB") if c in all_countries]
sel_countries = st.multiselect("Pays", options=all_countries, default=default_c, placeholder="Tous si vide")

# Horizon & seuils
col_h = st.columns(3)
horizon = col_h[0].selectbox("Horizon", options=list(HCOLS.keys()), index=2)
min_samples = col_h[1].slider("Min. échantillons (passé)", 1, 10, 3, step=1)
min_pips = col_h[2].slider("Seuil pips (médiane ou occurences ≥ seuil)", 0, 150, 20, step=5)

# Préréglages / regex
with st.expander("🔎 Filtres (préréglages & regex)", expanded=False):
    # Sélecteur de catégorie
    cat_names = ["(aucun)"] + list(PRESET_INCLUDE.keys())
    cat = st.selectbox("Préréglages — catégorie", options=cat_names, index=0)
    include_regex = ""
    if cat != "(aucun)":
        sub_opts = ["(aucun)"] + list(PRESET_INCLUDE[cat].keys())
        sub = st.selectbox("Préréglages — motif", options=sub_opts, index=0)
        if sub != "(aucun)":
            include_regex = PRESET_INCLUDE[cat][sub]

    # Affiner manuellement
    include_regex = st.text_input("Filtrer par mot-clé/regex (dans le titre)", value=include_regex, placeholder="ex: (interest\\s+rate\\s+decision|bank\\s+rate)")
    strict_decision = st.checkbox("Décisions strictes uniquement (exclut communiqués trop larges)", value=False)
    exclude_noise = st.checkbox("Exclure speeches / minutes / testimonies", value=True)

    exc_regex = EXCLUDE_NOISE_REGEX if exclude_noise else None

# Prévisualisation / compteur
n_filtered = _filter_count(DB_PATH, start_utc, end_utc, sel_countries, include_regex, exc_regex, strict_decision)
st.info(f"Après filtres: **{n_filtered}** événements (pays, dates, préréglages/regex, exclusions).")

with st.expander("Aperçu des titres retenus", expanded=False):
    c_cond, c_bind = _countries_condition(sel_countries)
    i_cond, i_bind = _regex_condition("event_title", include_regex)
    e_cond, e_bind = _not_regex_condition("event_title", exc_regex)
    s_cond, s_bind = _regex_condition("event_title", STRICT_DECISION_REGEX if strict_decision else None)
    sql_preview = f"""
      SELECT ts_utc, country, event_title
      FROM events
      WHERE ts_utc >= ? AND ts_utc < ?
      {c_cond} {i_cond} {e_cond} {s_cond}
      ORDER BY ts_utc DESC
      LIMIT 30
    """
    try:
        prev = duckdb.connect(DB_PATH).execute(sql_preview, [start_utc, end_utc, *c_bind, *i_bind, *e_bind, *s_bind]).df()
    except Exception as e:
        prev = pd.DataFrame({"error":[str(e)]})
    st.dataframe(prev, hide_index=True, width="stretch")

# Agrégat + évènements à venir
hcol = HCOLS[horizon]
agg, recent = _top_events_with_dates(
    DB_PATH, start_utc, end_utc, sel_countries, hcol,
    float(min_pips), int(min_samples),
    include_regex, EXCLUDE_NOISE_REGEX if exclude_noise else None,
    bool(strict_decision), 20
)

col1, col2 = st.columns([3,2])
with col1:
    st.subheader("Agrégats (passé)")
    if len(agg) == 0:
        st.warning("Aucun agrégat à afficher avec ces critères. Essaie d’élargir la période, d’assouplir le filtre, ou de baisser le seuil.")
    else:
        disp = agg.rename(columns={
            "event_key":"Clé d’événement",
            "country":"Pays",
            "event_title":"Titre type",
            "samples_total":"Échantillons (total)",
            "samples_past":"Échantillons (passé)",
            "samples_future":"À venir (comptés)",
            "median_mfe_past":f"Médiane {horizon}",
            "avg_mfe_past":f"Moyenne {horizon}",
            "hits_ge_thresh_past":f"Nb ≥ {int(min_pips)} pips (passé)",
        })
        st.dataframe(disp, hide_index=True, width="stretch")

with col2:
    st.subheader("À venir (titres & dates)")
    if len(recent) == 0:
        st.info("Aucun évènement à venir selon les filtres courants.")
    else:
        st.dataframe(recent.rename(columns={
            "ts_utc":"UTC",
            "country":"Pays",
            "event_title":"Titre",
            "event_key":"Clé",
        }), hide_index=True, width="stretch")

st.caption(
    "Notes :\n"
    f"• Horizon = colonne `{hcol}` sur la table `moves`.\n"
    "• Les métriques ‘médiane/moyenne’ sont calculées **sur le passé uniquement**.\n"
    "• Les filtres regex sont appliqués en **minuscule** via `lower(event_title)` ; évite les flags `(?i)` etc."
)

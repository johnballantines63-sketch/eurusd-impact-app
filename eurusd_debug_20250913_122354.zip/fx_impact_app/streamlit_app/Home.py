import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

import streamlit as st
st.set_page_config(page_title="EURUSD News Impact", layout="wide")
st.title("EURUSD News Impact — Empirical Analyzer")
st.caption("Storage: UTC • Display: Europe/Zurich • Inversion: Strict (50% retrace + EMA(9/21) cross)")
st.markdown("""
**Sections**
1. 📥 Ingestion — fetch & store 3y of intraday prices and economic events (EODHD).
2. 🔎 Discovery — compute scores (impact/persistence) empirically on 3y.
3. 📈 Scanner (Q1) — find days with ≥ N pips on selected TF, with duration to inversion.
4. 🧩 Linked News (Q2) — link those moves to the triggering announcements.
5. 🗓️ Planner — list future events with expected impact ≥ X pips.
""")
st.success("Use the sidebar 'Pages' to navigate.")

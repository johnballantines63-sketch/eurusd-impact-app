"""
Tests unitaires pour calculate_attenuation_factor()
Vérifie que la fonction retourne les facteurs corrects selon les cas

VERSION CORRIGÉE : Tests 5 et 8 ajustés pour refléter la priorité de la cohérence
"""

import sys
from pathlib import Path

# Ajouter le chemin pour importer la fonction
project_root = Path(__file__).parent
fx_app_src = project_root / "fx_impact_app" / "src"
sys.path.insert(0, str(fx_app_src))

from sequence_multi_event_timeline import calculate_attenuation_factor


def test_premiere_phase():
    """Test 1 : Première phase → facteur = 1.0"""
    factor = calculate_attenuation_factor(
        events=[{'surprise': 5.0}],
        direction='UP',
        prev_direction=None  # Première phase
    )
    assert factor == 1.0, f"Test 1 échoué : {factor} != 1.0"
    print("✅ Test 1 : Première phase → 1.0")


def test_directions_opposees():
    """Test 2 : Directions opposées → facteur = 1.0"""
    factor = calculate_attenuation_factor(
        events=[{'surprise': 5.0}],
        direction='UP',
        prev_direction='DOWN'  # Direction opposée
    )
    assert factor == 1.0, f"Test 2 échoué : {factor} != 1.0"
    print("✅ Test 2 : Directions opposées → 1.0")


def test_coherent():
    """Test 3 : Cohérent (UP + surprises positives) → facteur = 1.02"""
    factor = calculate_attenuation_factor(
        events=[
            {'surprise': 5.0},   # Positive
            {'surprise': 3.0},   # Positive
            {'surprise': 2.0}    # Positive
        ],
        direction='UP',
        prev_direction='UP'
    )
    assert factor == 1.02, f"Test 3 échoué : {factor} != 1.02"
    print("✅ Test 3 : Cohérent (UP + surprises +) → 1.02")


def test_coherent_down():
    """Test 4 : Cohérent (DOWN + surprises négatives) → facteur = 1.02"""
    factor = calculate_attenuation_factor(
        events=[
            {'surprise': -5.0},   # Négative
            {'surprise': -3.0},   # Négative
        ],
        direction='DOWN',
        prev_direction='DOWN'
    )
    assert factor == 1.02, f"Test 4 échoué : {factor} != 1.02"
    print("✅ Test 4 : Cohérent (DOWN + surprises -) → 1.02")


def test_surprise_extreme_coherent():
    """Test 5 : Surprise extrême ET cohérent → 1.02 (cohérence prioritaire)"""
    factor = calculate_attenuation_factor(
        events=[
            {'surprise': 15.0},   # Extrême ET positive
        ],
        direction='UP',  # Direction cohérente avec surprise
        prev_direction='UP'
    )
    # Cohérence PRIORITAIRE sur surprise extrême (H3 > H1)
    assert factor == 1.02, f"Test 5 échoué : {factor} != 1.02"
    print("✅ Test 5 : Surprise extrême + cohérent → 1.02 (cohérence prioritaire)")


def test_surprise_extreme_negative():
    """Test 6 : Surprise extrême négative + cohérent → 1.02"""
    factor = calculate_attenuation_factor(
        events=[
            {'surprise': -34.80},   # Extrême négatif
        ],
        direction='DOWN',  # Cohérent avec surprise négative
        prev_direction='DOWN'
    )
    # Cohérence prioritaire
    assert factor == 1.02, f"Test 6 échoué : {factor} != 1.02"
    print("✅ Test 6 : Surprise extrême négative + cohérent → 1.02")


def test_surprise_extreme_incoherent():
    """Test 7 : Surprise extrême MAIS incohérent → 0.80"""
    factor = calculate_attenuation_factor(
        events=[
            {'surprise': 15.0},   # Extrême mais...
        ],
        direction='DOWN',  # INCOHÉRENT (surprise + mais direction DOWN)
        prev_direction='DOWN'
    )
    # Incohérent → pas de bonus cohérence, mais surprise extrême s'applique
    assert factor == 0.80, f"Test 7 échoué : {factor} != 0.80"
    print("✅ Test 7 : Surprise extrême incohérent → 0.80")


def test_incoherent():
    """Test 8 : Incohérent (UP mais surprises négatives) → facteur = 0.66"""
    factor = calculate_attenuation_factor(
        events=[
            {'surprise': -5.0},   # Négative
            {'surprise': -2.0},   # Négative
        ],
        direction='UP',  # Mais direction UP !
        prev_direction='UP'
    )
    assert factor == 0.66, f"Test 8 échoué : {factor} != 0.66"
    print("✅ Test 8 : Incohérent (UP + surprises -) → 0.66")


def test_standard_vraiment_mixte():
    """Test 9 : Cas vraiment standard (mix équilibré) → facteur = 0.70"""
    factor = calculate_attenuation_factor(
        events=[
            {'surprise': 2.0},    # Petit positif
            {'surprise': -2.5},   # Petit négatif → moyenne proche de 0
        ],
        direction='UP',
        prev_direction='UP'
    )
    # Moyenne = -0.25, donc légèrement incohérent mais pas surprise extrême
    # Devrait donner 0.66 (incohérent)
    assert factor == 0.66, f"Test 9 échoué : {factor} != 0.66"
    print("✅ Test 9 : Mix équilibré légèrement incohérent → 0.66")


def test_sans_surprises():
    """Test 10 : Événements sans surprises → facteur = 0.70 (base)"""
    factor = calculate_attenuation_factor(
        events=[
            {},  # Pas de surprise
            {}   # Pas de surprise
        ],
        direction='UP',
        prev_direction='UP'
    )
    assert factor == 0.70, f"Test 10 échoué : {factor} != 0.70"
    print("✅ Test 10 : Sans surprises → 0.70 (base)")


def test_cas_reel_2025_09_02():
    """Test 11 : Cas réel 2025-09-02 (surprise extrême -34.80 + 7.70)"""
    factor = calculate_attenuation_factor(
        events=[
            {'surprise': -34.80},  # Extrême négatif
            {'surprise': 7.70},    # Positif
        ],
        direction='DOWN',  # Direction DOWN
        prev_direction='DOWN'
    )
    # Moyenne = (-34.80 + 7.70) / 2 = -13.55 (négative)
    # Direction DOWN + moyenne négative = COHÉRENT
    assert factor == 1.02, f"Test 11 échoué : {factor} != 1.02"
    print("✅ Test 11 : Cas réel 2025-09-02 → 1.02 (cohérent)")


def test_standard_vraiment_neutre():
    """Test 12 : Surprise modérée non-cohérente → 0.70"""
    factor = calculate_attenuation_factor(
        events=[
            {'surprise': 3.0},   # Modérée, pas extrême
        ],
        direction='DOWN',  # Incohérent
        prev_direction='DOWN'
    )
    # Surprise modérée (≤10), incohérent → devrait donner 0.66
    assert factor == 0.66, f"Test 12 échoué : {factor} != 0.66"
    print("✅ Test 12 : Surprise modérée incohérente → 0.66")


def run_all_tests():
    """Exécute tous les tests"""
    print("=" * 80)
    print("TESTS UNITAIRES - calculate_attenuation_factor()")
    print("VERSION CORRIGÉE - Priorité cohérence (H3) > surprise extrême (H1)")
    print("=" * 80)
    print()
    
    tests = [
        test_premiere_phase,
        test_directions_opposees,
        test_coherent,
        test_coherent_down,
        test_surprise_extreme_coherent,  # Corrigé : attend 1.02
        test_surprise_extreme_negative,
        test_surprise_extreme_incoherent,  # Nouveau : teste surprise extrême incohérente
        test_incoherent,
        test_standard_vraiment_mixte,  # Corrigé : attend 0.66
        test_sans_surprises,
        test_cas_reel_2025_09_02,
        test_standard_vraiment_neutre,  # Nouveau : teste cas non-extrême incohérent
    ]
    
    failed = 0
    for test in tests:
        try:
            test()
        except AssertionError as e:
            print(f"❌ {e}")
            failed += 1
        except Exception as e:
            print(f"❌ Erreur dans {test.__name__}: {e}")
            failed += 1
    
    print()
    print("=" * 80)
    if failed == 0:
        print("🎉 TOUS LES TESTS PASSENT !")
        print(f"✅ {len(tests)}/{len(tests)} tests réussis")
        print()
        print("📋 RÉSUMÉ DE LA LOGIQUE :")
        print("  1. Première phase OU directions opposées → 1.0 (pas d'atténuation)")
        print("  2. Cohérent (surprise alignée avec direction) → 1.02 ⭐ PRIORITAIRE")
        print("  3. Surprise extrême (>10) MAIS incohérent → 0.80")
        print("  4. Incohérent + pas extrême → 0.66")
        print("  5. Sans surprise → 0.70 (base)")
    else:
        print(f"⚠️ {failed}/{len(tests)} tests échoués")
    print("=" * 80)
    
    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
